/* @(#) $Header: report.h,v 1.3 96/06/04 22:40:53 leres Exp $ (LBL) */

void report(char *, u_int32_t, u_char *, u_char *, time_t *, time_t *);
