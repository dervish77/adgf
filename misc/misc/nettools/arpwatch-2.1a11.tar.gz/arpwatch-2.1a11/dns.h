/* @(#) $Header: dns.h,v 1.4 96/06/04 22:40:38 leres Exp $ (LBL) */

int	gethinfo(char *, char *, int, char *, int);
char	*gethname(u_int32_t);
char	*getsname(u_int32_t);
