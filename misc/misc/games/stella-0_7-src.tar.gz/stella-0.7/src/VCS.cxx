//============================================================================
//
//    SSSS    tt          lll  lll              
//   SS  SS   tt           ll   ll                
//   SS     tttttt  eeee   ll   ll   aaaa    "An Atari 2600 VCS Emulator"
//    SSSS    tt   ee  ee  ll   ll      aa      
//       SS   tt   eeeeee  ll   ll   aaaaa   Copyright (c) 1995,1996,1997
//   SS  SS   tt   ee      ll   ll  aa  aa         Bradford W. Mott
//    SSSS     ttt  eeeee llll llll  aaaaa    
//
//============================================================================

#include "machine.hxx"
#include "VCS.hxx"

//============================================================================
// Script is generated from the 'stella.vcs' file using sed
//============================================================================
static char* script =
#include "VCS.def"
;

//============================================================================
// Answer the default 'stella.vcs' scrip as a null-terminated array
//============================================================================
char* defaultVCSScript()
{
  return script;
}

