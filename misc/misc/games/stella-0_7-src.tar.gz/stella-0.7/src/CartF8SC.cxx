//============================================================================
//
//    SSSS    tt          lll  lll              
//   SS  SS   tt           ll   ll                
//   SS     tttttt  eeee   ll   ll   aaaa    "An Atari 2600 VCS Emulator"
//    SSSS    tt   ee  ee  ll   ll      aa      
//       SS   tt   eeeeee  ll   ll   aaaaa   Copyright (c) 1995,1996,1997
//   SS  SS   tt   ee      ll   ll  aa  aa         Bradford W. Mott
//    SSSS     ttt  eeeee llll llll  aaaaa    
//
//============================================================================

/**
  The 8K cartridge class used by Atari 'Super-chip' cartridges.  There
  are 2 4K banks and 128-bytes of RAM.

  @author  Bradford W. Mott
  @version $Id: CartF8SC.cxx,v 1.2 1997/05/17 19:00:04 bwmott Exp $
*/

#include "CartF8SC.hxx"
#include "System.hxx"

//============================================================================
// Constructor
//============================================================================
CartridgeF8SC::CartridgeF8SC(System& system, uByte* image)
    : Cartridge(system),
      myImageOffset(0),
      myRAMOffset(0)
{
  // Copy the ROM image into my buffer
  for(uWord bank = 0; bank < 2; ++bank)
  {
    for(uWord addr = 0; addr < 4096; ++addr)
    {
      myImage[(bank * 4096) + addr] = image[(bank * 4096) + addr];
    }
  }

  // Map all of my addresses in the system
  for(uWord addr = 0; addr < 8192; ++addr)
  {
    if(addr & 0x1000)
    {
      // Is this read address mapped to the cartridge RAM
      if((addr & 0x0f80) == 0x0080)
      {
        mySystem.mapPeek(addr, *this, &myRAM[addr & 0x007f], &myRAMOffset);
      }
      // Is this read address a "hot spot" or a read from "no where"
      else if(((addr & 0x0fff) == 0x0ff8) || ((addr & 0x0fff) == 0x0ff9) ||
          ((addr & 0x0f80) == 0x0000))
      {
        mySystem.mapPeek(addr, *this);
      }
      // Is this read address mapped to the standard ROM image
      else
      {
        mySystem.mapPeek(addr, *this, 
            &myImage[addr & 0x0fff], &myImageOffset);
      }

      // Is this write address mapped to the cartridge RAM
      if((addr & 0x0f80) == 0x0000)
        mySystem.mapPoke(addr, *this, &myRAM[addr & 0x007f]);
      else
        mySystem.mapPoke(addr, *this);
    }
  }

  // Reset myself
  reset();
}
 
//============================================================================
// Destructor
//============================================================================
CartridgeF8SC::~CartridgeF8SC()
{
}

//============================================================================
// Reset to my power on state
//============================================================================
void CartridgeF8SC::reset()
{
  // RAM's addressing offset is always zero
  myRAMOffset = 0;

  // Start execution in bank #1
  myImageOffset = 1 * 4096;
}

//============================================================================
// Answer the byte at the given address
//============================================================================
uByte CartridgeF8SC::peek(uWord addr)
{
  // Switch banks if necessary
  switch (addr & 0x0fff)
  {
    case 0x0ff8:    // Bank #0
      myImageOffset = 0 * 4096;
      break;

    case 0x0ff9:    // Bank #1
      myImageOffset = 1 * 4096;
      break;

    default:
      break; 
  }
  return myImage[myImageOffset + (addr & 0x0fff)];
}

//============================================================================
// Store value in the given address
//============================================================================
void CartridgeF8SC::poke(uWord addr, uByte)
{
  // Switch banks if necessary
  switch (addr & 0x0fff)
  {
    case 0x0ff8:    // Bank #0
      myImageOffset = 0 * 4096;
      break;

    case 0x0ff9:    // Bank #1
      myImageOffset = 1 * 4096;
      break;

    default:
      break; 
  }
}

