//============================================================================
//
//    SSSS    tt          lll  lll              
//   SS  SS   tt           ll   ll                
//   SS     tttttt  eeee   ll   ll   aaaa    "An Atari 2600 VCS Emulator"
//    SSSS    tt   ee  ee  ll   ll      aa      
//       SS   tt   eeeeee  ll   ll   aaaaa   Copyright (c) 1995,1996,1997
//   SS  SS   tt   ee      ll   ll  aa  aa         Bradford W. Mott
//    SSSS     ttt  eeeee llll llll  aaaaa    
//
//============================================================================

#ifndef SOUNDDOS_HXX
#define SOUNDDOS_HXX

#include "machine.hxx"
#include "Snd.hxx"

/**
  Sound class for the MS-DOS operating system with sound-blaster cards.

  @author  Bradford W. Mott
  @version $Id: SndDOS.hxx,v 1.2 1997/05/17 19:00:07 bwmott Exp $
*/
class SoundDOS : public Sound
{
  public:
    /// Constructor
    SoundDOS();
 
    /// Destructor
    virtual ~SoundDOS();

  public: 
    /// Set the given sound register to the specified value
    virtual void set(Sound::Register reg, uByte value);

  private:
    bool myEnabled;
};
#endif

