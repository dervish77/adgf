//============================================================================
//
//    SSSS    tt          lll  lll              
//   SS  SS   tt           ll   ll                
//   SS     tttttt  eeee   ll   ll   aaaa    "An Atari 2600 VCS Emulator"
//    SSSS    tt   ee  ee  ll   ll      aa      
//       SS   tt   eeeeee  ll   ll   aaaaa   Copyright (c) 1995,1996,1997
//   SS  SS   tt   ee      ll   ll  aa  aa         Bradford W. Mott
//    SSSS     ttt  eeeee llll llll  aaaaa    
//
//============================================================================

/**
  Abstract base class that defines the standard API for the 
  terminal displays.

  @author  Bradford W. Mott
  @version $Id: BasTerm.cxx,v 1.2 1997/05/17 19:00:02 bwmott Exp $
*/

#include "BasTerm.hxx"

//============================================================================
// Constructor
//============================================================================
BasicTerminal::BasicTerminal()
{
}
 
//============================================================================
// Destructor
//============================================================================
BasicTerminal::~BasicTerminal()
{
}


