/* c_star.cc 1.9 95/12/23 03:11:29 */


// xspacewarp by Greg Walker (gow@math.orst.edu)

// This is free software. Non-profit redistribution and/or modification
// is allowed and welcome.


// class star methods. not much.


#include "c_star.hh"
#include "c_body.hh"
#include <stdlib.h>
#include <iostream.h>
#include "space_objects.hh"


void Star::draw(Drawable drawable, GC gc) const
{
  Body *bdy = (Body *)this;

  bdy->draw(drawable, gc, icon, icon_len);
}


/******************* static members ***********************/

const int Star::icon_len = 1;
char Star::icon[icon_len+1];

void Star::seticon(const char *str)
{
  if (strlen(str) != icon_len)
  {
    cerr << "xspacewarp: bad star icon in X resources." << endl;
    exit(1);
  }
  (void) strcpy(icon, str);
}

int Star::geticon_len()
{
  return (icon_len);
}

// end
