/* c_celestial.hh 1.6 95/12/23 03:11:29 */


// xspacewarp by Greg Walker (gow@math.orst.edu)

// This is free software. Non-profit redistribution and/or modification
// is allowed and welcome.


// this class did not get much use. connects stars and blackholes in the
// space object hierarchy.

#ifndef _CELESTIAL_
#define _CELESTIAL_

#include "c_body.hh"

class Celestial: public Body
{
public:
  Celestial(): Body() {}
};


#endif _CELESTIAL_

// end
