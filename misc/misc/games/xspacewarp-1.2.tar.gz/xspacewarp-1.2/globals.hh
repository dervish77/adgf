/* globals.hh 1.11 95/12/23 03:11:19 */


// xspacewarp by Greg Walker (gow@math.orst.edu)

// This is free software. Non-profit redistribution and/or modification
// is allowed and welcome.


#ifndef _GLOBALS_
#define _GLOBALS_

#include <X11/Intrinsic.h>
#include <X11/StringDefs.h>
#include "app_data.hh"
#include "common.hh"
#include "params.hh"
#include "c_sector.hh"
#include "c_endever.hh"

extern XtAppContext app_context;
extern AppData app_data;
extern Widget toplevel, widget;
extern Pixmap pixmap;
extern GC def_GC, defrv_GC, faserGC, faserGC_rv, torpGC, torpGC_rv, explodeGC;
extern GC endeverGC, baseGC, jovianGC, starGC, blackholeGC;

extern Sector universe[UROWS][UCOLS];
extern GameState gamestate;
extern Endever endever;


#endif				// _GLOBALS_

// end
