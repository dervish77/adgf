/* c_blackhole.hh 1.7 95/12/23 03:11:29 */


// xspacewarp by Greg Walker (gow@math.orst.edu)

// This is free software. Non-profit redistribution and/or modification
// is allowed and welcome.


/* c_blackhole.hh 1.7 95/12/23 03:11:29 */

// class for describing blackholes.

#ifndef _BLACKHOLE_
#define _BLACKHOLE_


#include "c_celestial.hh"
#include <X11/Xlib.h>
#include "space_objects.hh"

class Blackhole: public Celestial
{
public:
  Blackhole(): Celestial() {}
  Identity what() const {return (BLACKHOLE);}
  void draw(Drawable drawable, GC gc) const;
  static void seticon(const char *str);
  static int geticon_len();
private:
  static char icon[];
  static const int icon_len;
};


#endif				// _BLACKHOLE_

// end
