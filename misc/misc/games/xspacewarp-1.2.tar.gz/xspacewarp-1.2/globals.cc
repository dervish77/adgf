/* globals.cc 1.13 95/12/23 03:11:19 */


// xspacewarp by Greg Walker (gow@math.orst.edu)

// This is free software. Non-profit redistribution and/or modification
// is allowed and welcome.


#include <X11/Intrinsic.h>
#include <X11/StringDefs.h>
#include "app_data.hh"
#include "common.hh"
#include "params.hh"
#include "c_sector.hh"
#include "c_endever.hh"

XtAppContext app_context;
AppData app_data;		// application defined resources
Widget toplevel;

// the only widget used in this program. serves as a drawing canvas.

Widget widget;

// use pixmap as backing-store

Pixmap pixmap;

// Graphics Contexts
// def_GC is default GC used for drawing text and borders.
// defrv_GC is the reverse video counterpart of def_GC.
// torp_GC is for drawing torpedoes. explodeGC is for drawing explosions.

GC def_GC, defrv_GC, faserGC, faserGC_rv, torpGC, torpGC_rv, explodeGC;
GC endeverGC, baseGC, jovianGC, starGC, blackholeGC;

// 2x2 array of sectors handles all bookkeeping in game: where things are
// at, how many things are there, etc.

Sector universe[UROWS][UCOLS];

// Gamestate is collection of flags indicating what is being displayed on
// the screen at any given time and how keyboard input is to be interpreted
// (as faser angles, shield level, a sector coor, etc).

GameState gamestate = {0, INTRO, SKILL};
Endever endever;

// end
