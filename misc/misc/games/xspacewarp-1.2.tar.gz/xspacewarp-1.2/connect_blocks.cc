/* connect_blocks.cc 1.2 95/12/23 03:11:40 */


// xspacewarp by Greg Walker (gow@math.orst.edu)

// This is free software. Non-profit redistribution and/or modification
// is allowed and welcome.


#include <X11/Xlib.h>
#include "common.hh"
#include "params.hh"
#include "c_block.hh"
#include "globals.hh"

// Connect the centers of two 9x15 blocks with a line.

void connect_blocks(Drawable drawable, GC gc, Block& block1, Block& block2)
{
  Point center1, center2;	// centers of the blocks

  center1 = block1.center();
  center2 = block2.center();
  XDrawLine(DISPLAY, drawable, gc,
	    center1.x, center1.y, center2.x, center2.y);
}

// end
