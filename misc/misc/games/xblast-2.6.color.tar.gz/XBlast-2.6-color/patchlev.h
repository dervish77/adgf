/*
 * Program XBLAST V2.6 or higher
 * (C) by Oliver Vogel (e-mail: vogel@ikp.uni-koeln.de)
 * July 28th, 1999
 * started August 1993
 *
 * File: patchlev.h
 * just the version number 
 *
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public Licences as by published
 * by the Free Software Foundation; either version 2; or (at your option)
 * any later version
 *
 * This program is distributed in the hope that it will entertaining,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of 
 * MERCHANTABILTY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.
 * 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 * $Id: patchlev.h,v 1.5 1999/08/13 19:06:32 xblast Exp $
 * $Log: patchlev.h,v $
 * Revision 1.5  1999/08/13 19:06:32  xblast
 * space between Sound and Copyright inserted
 *
 * Revision 1.4  1999/08/13 17:50:58  xblast
 * new email address for Garth
 *
 * Revision 1.3  1999/07/28 19:32:44  xblast
 * version 2.6!
 *
 * Revision 1.2  1998/10/18 12:30:04  xblast
 * Morphing Bomb extra
 *
 * Revision 1.1  1998/01/03 14:09:04  xblast
 * Initial revision
 *
 */

#define XBLAST_VERSION "XBlast 2.6"

#ifdef _MAIN_C
static char win_string1[] = XBLAST_VERSION " - %s";
static char win_string2[] = XBLAST_VERSION " - %s & %s";
static char icon_string[] = XBLAST_VERSION;
static char c_string[] = 
XBLAST_VERSION
#ifdef XBLAST_SOUND
" Sound"
#endif
" Copyright (c) 1993-99 Oliver Vogel"
#ifdef DEBUG
"\n(build " __DATE__ " " __TIME__ ")"
#endif
;
#endif

#ifdef _INTRO_C
#ifdef XBLAST_SOUND
#define NUM_XC 9
#else
#define NUM_XC 7
#endif
static char *xc_string[NUM_XC] = {
  NULL,
  NULL,
  XBLAST_VERSION,
  "Copyright \251 1993-99 Oliver Vogel",
  "(m.vogel@ndh.net)",
  "Coauthor Garth Denley",
  "(garthy@camtech.net.au)",
#ifdef XBLAST_SOUND
  "Sound by Norbert Nicolay",
  "(nicolay@ikp.uni-koeln.de)",
#endif
};
#endif

/*
 * end of file patchlev.h
 */
