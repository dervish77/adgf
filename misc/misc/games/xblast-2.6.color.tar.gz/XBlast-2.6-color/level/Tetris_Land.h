/* XBlast 2.5.3 level */
static BMLevelData Tetris_Land =
{
  /* BMLevel */
  {
    "Tetris Land",
    "Olivier Gladin",
    "xblast.useTetris_Land",
    "The master is here... You're dead",
    GM_Random | GM_23456_Player | GM_All,
    (void *) &Tetris_Land,
    NULL,
  },
  /* BMShrinkData */
  {
    shrink_spiral_3,
    SCRAMBLE_VOID,
    SCRAMBLE_VOID,
  },
  /* BMFuncData */
  {
    special_init_void,
    special_game_void,
    special_extra_void,
    special_key_RC,
  },
  /* BMPlayerData */
  {
    3, 3,
    {
      {  1,  1 },
      {  1, 13 },
      {  3,  5 },
      {  9,  9 },
      { 11,  1 },
      { 11, 13 },
    },
    PM_Inner, 2,
    Healthy, Healthy, IF_RC | IF_Kick, 
  },
  /* BMBombData */
  {
    bomb_click_none, bomb_click_none, bomb_click_none,
    GoStop, FUSEnormal,
    BMTnormal, BMTnormal, BMTnormal,
  },
  /* BMGraphicsData */
  {
    {
      { "button_floor", "Black", "Gray75", "Black" },
      { "button_floor", "Black", "Gray75", "Black" },
      { "dark_block", "Black", "LightBlue", "SpringGreen" },
      { "dark_block_R", "Black", "LightBlue", "SpringGreen" },
      { "box", "Black", "LightBlue", "Red" },
      { "box", "Black", "HotPink", "Red" },
      EXTRA_BOMB,
      EXTRA_RANGE,
      EXTRA_TRAP,
      EXTRA_KICK,
      { "score_floor", "Red", "Red", "RoyalBlue" },
    },
  },
  /* BMMapData */
  {
    ShadowBlock, DEnone,
    { 0,99, 0, 0, 0},
    {
      { B,B,B,B,B,B,B,B,B,B,B,B,B },
      { B,_,_,X,_,X,_,_,_,X,_,_,B },
      { B,_,_,B,X,X,_,_,B,B,_,_,B },
      { B,X,B,B,_,B,B,X,X,B,B,X,B },
      { B,_,X,B,X,B,B,X,_,_,X,_,B },
      { B,X,X,_,_,X,_,_,B,_,B,_,B },
      { B,_,B,_,_,X,_,_,B,_,B,_,B },
      { B,_,B,X,B,B,_,B,B,X,B,_,B },
      { B,_,B,_,B,_,_,X,_,_,B,_,B },
      { B,X,B,_,B,_,_,X,_,_,X,X,B },
      { B,_,X,_,_,X,B,B,X,B,X,_,B },
      { B,X,B,B,X,X,B,B,_,B,B,X,B },
      { B,_,_,B,B,_,_,X,X,B,_,_,B },
      { B,_,_,X,_,_,_,X,_,X,_,_,B },
      { B,B,B,B,B,B,B,B,B,B,B,B,B }
    },
  },
};
