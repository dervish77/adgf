/* XBlast 2.5.3 level */
static BMLevelData CrualRebounds =
{
  /* BMLevel */
  {
    "Crual Rebounds",
    "Cyril Maestraggi",
    "xblast.useCrualRebounds",
    "Enter is the key",
    GM_Random | GM_23456_Player | GM_All,
    (void *) &CrualRebounds,
    NULL,
  },
  /* BMShrinkData */
  {
    shrink_void,
    SCRAMBLE_VOID,
    SCRAMBLE_VOID,
  },
  /* BMFuncData */
  {
    special_init_void,
    special_game_void,
    special_extra_void,
    special_key_RC,
  },
  /* BMPlayerData */
  {
    2, 4,
    {
      {  1, 13 },
      {  2,  7 },
      {  4,  3 },
      {  8, 11 },
      { 10,  7 },
      { 11,  1 },
    },
    PM_Polar, 3,
    Healthy, Healthy, IF_Kick | IF_RC,
  },
  /* BMBombData */
  {
    bomb_click_contact, bomb_click_clockwise, bomb_click_none,
    GoStop, FUSEnormal,
    BMTnormal, BMTnormal, BMTnormal,
  },
  /* BMGraphicsData */
  {
    {
      { "iron_floor", "Black", "IndianRed", "Yellow" },
      { "iron_floor_S", "Black", "IndianRed", "Yellow" },
      { "dark_block", "Black", "SlateBlue", "Cyan" },
      { "dark_block_R", "Black", "SlateBlue", "LightSlateBlue" },
      { "extra", "Black", "SaddleBrown", "Black" },
      { "extra", "Black", "SaddleBrown", "Black" },
      EXTRA_BOMB,
      EXTRA_RANGE,
      EXTRA_TRAP,
      EXTRA_INVINC,
      { "score_floor", "RoyalBlue", "RoyalBlue", "RoyalBlue" },
    },
  },
  /* BMMapData */
  {
    ShadowBlock, DEnone,
    { 0, 0, 0, 0, 0 },
    {
      { B,B,B,B,B,B,B,B,B,B,B,B,B, },
      { B,B,_,_,_,_,_,_,_,_,_,_,B, },
      { B,_,_,_,_,_,_,_,_,_,B,_,B, },
      { B,_,_,B,_,_,_,_,_,_,_,_,B, },
      { B,_,_,_,_,_,_,_,B,_,_,_,B, },
      { B,_,_,_,_,B,_,_,_,_,_,_,B, },
      { B,_,_,_,_,_,_,_,_,_,_,_,B, },
      { B,_,_,_,_,_,_,_,_,_,_,_,B, },
      { B,_,_,_,_,_,_,_,_,_,_,_,B, },
      { B,_,_,_,_,_,_,B,_,_,_,_,B, },
      { B,_,_,_,B,_,_,_,_,_,_,_,B, },
      { B,_,_,_,_,_,_,_,_,B,_,_,B, },
      { B,_,B,_,_,_,_,_,_,_,_,_,B, },
      { B,_,_,_,_,_,_,_,_,_,_,B,B, },
      { B,B,B,B,B,B,B,B,B,B,B,B,B, },
    },
  },
};
