/* XBlast 2.5.3 level */
static BMLevelData Popcorn =
{
  /* BMLevel */
  {
    "Popcorn",
    "Garth Denley",
    "xblast.usePopcorn",
    "Pepper your opponents with bombs",
    GM_Random | GM_23456_Player | GM_All,
    (void *) &Popcorn,
    NULL,
  },
  /* BMShrinkData */
  {
    shrink_spiral,
    SCRAMBLE_VOID,
    SCRAMBLE_VOID,
  },
  /* BMFuncData */
  {
    special_init_void,
    special_game_void,
    special_extra_invincible,
    special_key_void,
  },
  /* BMPlayerData */
  {
    2, 1,
    {
      {  2,  2 },
      {  2, 12 },
      { 10, 12 },
      { 10,  2 },
      {  4,  7 },
      {  8,  7 },
    },
    PM_LeftRight, 1,
    Healthy, Healthy, IF_Kick,
  },
  /* BMBombData */
  {
    bomb_click_contact, bomb_click_none, bomb_click_none,
    GoStop, FUSEnormal,
    BMTnormal, BMTnormal, BMTnormal,
  },
  /* BMGraphicsData */
  {
    {
      { "lego_floor", "Black", "MediumSeagreen", "SpringGreen" },
      { "lego_floor_S", "Black", "MediumSeagreen", "SpringGreen" },
      { "lego_white", "Black", "Gold", "MediumSeaGreen" },
      { "lego_white", "Black", "LightYellow", "MediumSeaGreen" },
      { "lego_black", "LightSteelBlue", "Black", "MediumSeaGreen" },
      { "lego_black_O", "LightSteelBlue", "Black", "Black" },
      EXTRA_BOMB,
      EXTRA_RANGE,
      EXTRA_TRAP,
      EXTRA_INVINC,
      { "score_floor", "RoyalBlue", "RoyalBlue", "RoyalBlue" },
    },
  },
  /* BMMapData */
  {
    ShadowFull, DEnone,
    { 40, 40, 40, 50, 50 },
    {
      { B,B,B,B,B,B,B,B,B,B,B,B,B, },
      { B,X,_,_,_,X,X,X,_,_,_,X,B, },
      { B,_,_,X,B,B,_,B,B,X,_,_,B, },
      { B,X,_,_,_,_,_,_,_,_,_,X,B, },
      { B,_,B,_,X,X,_,X,X,_,B,_,B, },
      { B,_,B,_,B,X,_,X,B,_,B,_,B, },
      { B,_,X,_,_,_,X,_,_,_,X,_,B, },
      { B,_,_,_,_,X,X,X,_,_,_,_,B, },
      { B,_,X,_,_,_,X,_,_,_,X,_,B, },
      { B,_,B,_,B,X,_,X,B,_,B,_,B, },
      { B,_,B,_,X,X,_,X,X,_,B,_,B, },
      { B,X,_,_,_,_,_,_,_,_,_,X,B, },
      { B,_,_,X,B,B,_,B,B,X,_,_,B, },
      { B,X,_,_,_,X,X,X,_,_,_,X,B, },
      { B,B,B,B,B,B,B,B,B,B,B,B,B, },
    },
  },
};
