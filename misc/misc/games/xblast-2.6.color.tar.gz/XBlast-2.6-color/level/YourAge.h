/* XBlast 2.5.3 level */
static BMLevelData YourAge =
{
  /* BMLevel */
  {
    "When I was Your Age",
    "Garth Denley",
    "xblast.useYourAge",
    "Use the long fuses to set up traps",
    GM_Random | GM_23456_Player | GM_All,
    (void *) &YourAge,
    NULL,
  },
  /* BMShrinkData */
  {
    shrink_void,
    SCRAMBLE_VOID,
    SCRAMBLE_VOID,
  },
  /* BMFuncData */
  {
    special_init_void,
    special_game_void,
    special_extra_void,
    special_key_void,
  },
  /* BMPlayerData */
  {
    7, 3,
    {
      {  4,  5 },
      {  4,  9 },
      {  8,  9 },
      {  8,  5 },
      {  6,  6 },
      {  6,  8 },
    },
    PM_Polar, 1,
    Healthy, Healthy, IF_None,
  },
  /* BMBombData */
  {
    bomb_click_none, bomb_click_none, bomb_click_none,
    GoStop, FUSElong,
    BMTnormal, BMTnormal, BMTnormal,
  },
  /* BMGraphicsData */
  {
    {
      { "city_free", "Black", "Gray65", "Gray40" },
      { "city_free_S", "Black", "Gray65", "Gray40" },
      { "dark_house", "Black", "Firebrick", "Burlywood" },
      { "dark_house_R", "Black", "Firebrick", "Burlywood" },
      { "score_floor", "Black", "Tan", "Black" },
      EXTRA_BOMB,
      EXTRA_RANGE,
      EXTRA_TRAP,
      { "iron_floor", "Black", "Gray25", "OrangeRed" },
      { "iron_floor", "Black", "Gray25", "OrangeRed" },
      { "score_floor", "RoyalBlue", "RoyalBlue", "RoyalBlue" },
    },
  },
  /* BMMapData */
  {
    ShadowFull, DEnone,
    { 0, 0, 0, 0, 0 },
    {
      { q,q,q,q,B,X,X,X,B,q,q,q,q, },
      { q,q,q,q,B,X,X,X,B,q,q,q,q, },
      { q,q,q,q,B,X,X,X,B,q,q,q,q, },
      { q,q,B,B,B,B,B,B,B,B,B,q,q, },
      { B,B,B,_,_,_,_,_,_,_,B,B,B, },
      { X,X,B,_,_,_,_,_,_,_,B,X,X, },
      { X,X,B,_,_,B,_,B,_,_,B,X,X, },
      { X,X,B,_,_,_,_,_,_,_,B,X,X, },
      { X,X,B,_,_,B,_,B,_,_,B,X,X, },
      { X,X,B,_,_,_,_,_,_,_,B,X,X, },
      { B,B,B,_,_,_,_,_,_,_,B,B,B, },
      { q,q,B,B,B,B,B,B,B,B,B,q,q, },
      { q,q,q,q,B,X,X,X,B,q,q,q,q, },
      { q,q,q,q,B,X,X,X,B,q,q,q,q, },
      { q,q,q,q,B,X,X,X,B,q,q,q,q, },
    },
  },
};
