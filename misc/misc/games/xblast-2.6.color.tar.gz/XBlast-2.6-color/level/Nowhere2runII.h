/* XBlast 2.5.3 level */
/* File: level/Nowhere2runII.h */
/* Author: Stephan Natschlaeger */
/* Version: 16.12.1997 */
static BMLevelData Nowhere2runII =
{
  /* BMLevel */
  {
    "Nowhere To Run II",
    "Stn",
    "xblast.useNowhere2runII",
    "Build Your Own Walls",
    GM_Random | GM_23456_Player | GM_All,
    (void *) &Nowhere2runII,
    NULL,
  },
  /* BMShrinkData */
  {
    shrink_spiral,
    SCRAMBLE_VOID,
    SCRAMBLE_VOID,
  },
  /* BMFuncData */
  {
    special_init_special_bombs_30,
    special_game_void,
    special_extra_void,
    special_key_special_bomb,
  },
  /* BMPlayerData */
  {
    7, 13,
    {
      {  5,  5 },
      {  5,  9 },
      {  7,  9 },
      {  7,  5 },
      {  4,  7 },
      {  8,  7 },
    },
    PM_Polar, -1,
    Healthy, Healthy, IF_Kick,
  },
  /* BMBombData */
  {
    bomb_click_snooker, bomb_click_none, bomb_click_none,
    GoStop, FUSEnormal,
    BMTnormal, BMTconstruction, BMTnormal,
  },
  /* BMGraphicsData */
  {
    {
      { "iron_floor", "Black", "Gray20", "SpringGreen" },
      { "iron_floor_S", "Black", "Gray20", "SpringGreen" },
      { "dark_block", "MidnightBlue", "RoyalBlue", "Black" },
      { "dark_block_R", "RoyalBlue", "White", "White" },
      { "extra", "Black", "SaddleBrown", "Black" },
      { "extra", "Black", "SaddleBrown", "Black" },
      EXTRA_BOMB,
      EXTRA_RANGE,
      EXTRA_TRAP,
      EXTRA_INVINC,
      { "score_floor", "RoyalBlue", "RoyalBlue", "RoyalBlue" },
    },
  },
  /* BMMapData */
  {
    ShadowBlock, DEnone,
    { 0, 0, 0, 0, 0 },
    {
      { B,B,B,B,B,B,B,B,B,B,B,B,B, },
      { B,_,_,_,_,_,_,_,_,_,_,_,B, },
      { B,_,_,_,_,_,_,_,_,_,_,_,B, },
      { B,_,_,_,_,_,_,_,_,_,_,_,B, },
      { B,_,_,_,_,_,_,_,_,_,_,_,B, },
      { B,_,_,_,_,_,_,_,_,_,_,_,B, },
      { B,_,_,_,_,_,_,_,_,_,_,_,B, },
      { B,_,_,_,_,_,_,_,_,_,_,_,B, },
      { B,_,_,_,_,_,_,_,_,_,_,_,B, },
      { B,_,_,_,_,_,_,_,_,_,_,_,B, },
      { B,_,_,_,_,_,_,_,_,_,_,_,B, },
      { B,_,_,_,_,_,_,_,_,_,_,_,B, },
      { B,_,_,_,_,_,_,_,_,_,_,_,B, },
      { B,_,_,_,_,_,_,_,_,_,_,_,B, },
      { B,B,B,B,B,B,B,B,B,B,B,B,B, },
    },
  },
};
