/* XBlast 2.5.3 level */
static BMLevelData Pandemonium =
{
  /* BMLevel */
  {
    "Pandemonium",
    "Keith Gillow",
    "xblast.usePandemonium",
    "Use the skulls wisely",
    GM_Random | GM_234_Player | GM_All,
    (void *) &Pandemonium,
    NULL,
  },
  /* BMShrinkData */
  {
    shrink_void,
    SCRAMBLE_VOID,
    SCRAMBLE_VOID,
  },
  /* BMFuncData */
  {
    special_init_void,
    special_game_void,
    special_extra_RC,
    special_key_RC,
  },
  /* BMPlayerData */
  {
    6, 3,
    {
      {  1,  1 },
      {  1, 13 },
      { 11, 13 },
      { 11,  1 },
    },
    PM_Polar, 2,
    IllTeleport, IllTeleport, IF_Kick,
  },
  /* BMBombData */
  {
    bomb_click_none, bomb_click_none, bomb_click_thru,
    GoStop, FUSEnormal,
    BMTnormal, BMTnormal, BMTnormal,
  },
  /* BMGraphicsData */
  {
    {
      { "city_free", "Black", "Gray65", "Gray40" },
      { "city_free_S", "Black", "Gray65", "Gray40" },
      { "dark_house", "Black", "Firebrick", "Burlywood" },
      { "dark_house_R", "Black", "Firebrick", "Burlywood" },
      { "score_floor", "Black", "Tan", "Black" },
      { "score_floor", "Black", "Tan", "Black" },
      EXTRA_BOMB,
      EXTRA_RANGE,
      EXTRA_TRAP,
      EXTRA_RC,
      { "iron_floor", "Black", "Gray25", "OrangeRed" },
    },
  },
  /* BMMapData */
  {
    ShadowFull, DEnone,
    { 3, 7, 55, 57, 59 },
    {
      { v,B,B,B,B,B,B,B,B,B,B,B,v, },
      { B,_,b,_,_,X,q,X,_,_,b,_,B, },
      { B,b,s,_,_,X,X,X,_,_,s,b,B, },
      { B,_,_,_,_,_,_,_,_,_,_,_,B, },
      { B,s,B,B,_,B,_,B,_,B,B,s,B, },
      { B,_,_,_,_,_,_,_,_,_,_,_,B, },
      { B,X,X,_,_,_,s,_,_,_,X,X,B, },
      { B,q,X,_,_,B,_,B,_,_,X,q,B, },
      { B,X,X,_,_,_,s,_,_,_,X,X,B, },
      { B,_,_,_,_,_,_,_,_,_,_,_,B, },
      { B,s,B,B,_,B,_,B,_,B,B,s,B, },
      { B,_,_,_,_,_,_,_,_,_,_,_,B, },
      { B,b,s,_,_,X,X,X,_,_,s,b,B, },
      { B,_,b,_,_,X,q,X,_,_,b,_,B, },
      { v,B,B,B,B,B,B,B,B,B,B,B,v, },
    },
  },
};
