/* XBlast 2.5.3 level */
static BMLevelData Gravity =
{
  /* BMLevel */
  {
    "Gravity",
    "The Adelaide Group (lscamero)",
    "xblast.useGravity",
    "I was up above it but now I'm down in it.",
    GM_Random | GM_23456_Player | GM_All,
    (void *) &Gravity,
    NULL,
  },
  /* BMShrinkData */
  {
    shrink_compound,
    SCRAMBLE_VOID,
    SCRAMBLE_VOID,
  },
  /* BMFuncData */
  {
    special_init_void,
    special_game_void,
    special_extra_void,
    special_key_void,
  },
  /* BMPlayerData */
  {
    5, 10,
    {
      {  1,  1 },
      {  1,  5 },
      {  1,  9 },
      {  1, 13 },
      {  1,  3 },
      {  1, 11 },
    },
    PM_Below, 10,
    Healthy, Healthy, IF_None,
  },
  /* BMBombData */
  {
    bomb_click_none, bomb_click_none, bomb_click_initial,
    GoDown, FUSEnormal,
    BMTnormal, BMTnormal, BMTnormal,
  },
  /* BMGraphicsData */
  {
    {
      { "check",         "Black", "Yellow", "Gray50" },
      { "check",         "Black", "Yellow", "Gray50" },
      { "downarrow",     "Black", "Red", "Blue" },
      { "downarrow",     "Black", "Red", "Blue" },
      { "chess_sphere",   "Black", "White", "Gray50" },
      { "chess_sphere_O", "Black", "White", "Gray50" },
      EXTRA_BOMB,
      EXTRA_RANGE,
      EXTRA_TRAP,
      EXTRA_MAYHEM,
      { "check",         "Black", "Cyan", "Gray50" },
    },
  },
  /* BMMapData */
  {
    ShadowFull, DEall,
    { 0, 0, 0, 0, 0 },
    {
      { B,B,B,B,B,B,B,B,B,B,B,B,B },
      { B,_,_,_,_,_,_,_,_,_,_,_,B },
      { B,_,B,_,B,_,B,_,B,_,B,_,B },
      { B,_,_,_,_,_,_,_,_,_,_,_,B },
      { B,_,B,_,B,_,B,_,B,_,B,_,B },
      { B,_,_,_,_,_,_,_,_,_,_,_,B },
      { B,_,B,_,B,_,B,_,B,_,B,_,B },
      { B,_,_,_,_,_,_,_,_,_,_,_,B },
      { B,_,B,_,B,_,B,_,B,_,B,_,B },
      { B,_,_,_,_,_,_,_,_,_,_,_,B },
      { B,_,B,_,B,_,B,_,B,_,B,_,B },
      { B,_,_,_,_,_,_,_,_,_,_,_,B },
      { B,_,B,_,B,_,B,_,B,_,B,_,B },
      { B,_,_,_,_,_,_,_,_,_,_,_,B },
      { B,B,B,B,B,B,B,B,B,B,B,B,B }
    },
  },
};
