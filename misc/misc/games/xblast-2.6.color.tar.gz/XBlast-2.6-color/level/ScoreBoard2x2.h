/* XBlast 2.5.3 level */
static BMLevelData ScoreBoard2x2 =
{
  /* BMLevel */
  {
    "SCOREBOARD",
    "xblast.useScoreBoard",
    "",
    "Even this level needs no description",
    GM_4_Player | GM_NoGrid | GM_Team | GM_LR_Players,
    (void *) &ScoreBoard2x2,
    NULL,
  },
  /* BMShrinkData */
  {
    shrink_void,
    SCRAMBLE_VOID,
    SCRAMBLE_VOID,
  },
  /* BMFuncData */
  {
    special_init_void,
    special_game_void,
    special_extra_void,
    special_key_void,
  },
  /* BMPlayerData */
  {
    0, 0,
    {
      { BLOCK_HEIGHT*9/2, BLOCK_WIDTH*4 },
      { BLOCK_HEIGHT*9/2, BLOCK_WIDTH*5 },
      { BLOCK_HEIGHT*17/2, BLOCK_WIDTH*4 },
      { BLOCK_HEIGHT*17/2, BLOCK_WIDTH*5 },
      { -1, -1 },
      { -1, -1 },
    },
    PM_Same, 0,
    Healthy, Healthy, IF_None,
  },
  /* BMBombData */
  {
    bomb_click_none, bomb_click_none, bomb_click_none,
    GoStop, FUSEnormal,
    BMTnormal, BMTnormal, BMTnormal,
  },
  /* BMGraphicsData */
  {
    {
      { "score_right_up", "Black", "LightSteelBlue", "Black" },
      { "score_right_down", "Black", "FireBrick1", "Black" },
      { "score_mid_up", "Black", "SpringGreen", "LightSteelBlue" },
      { "score_mid_down", "Black", "Firebrick1", "LightSteelBlue" },
      { "score_left_up", "Black", "SpringGreen", "LightSteelBlue" },
      { "score_left_down", "Black", "Firebrick1", "LightSteelBlue" },
      { "score_floor", "Black", "SpringGreen", "Black" },
      { "score_step", "Black", "Firebrick1", "LightSteelBlue" },
      { "score_drop", "Black", "Firebrick1", "SpringGreen" },
      { "score_floor", "Black", "Black", "Black" },
      { "score_floor", "RoyalBlue", "RoyalBlue", "RoyalBlue" },
    },
  },
  /* BMMapData */
  {
    ShadowNone, DEnone,
    { 0, 0, 0, 0, 0 },
    {
      { 7,7,7,6,6,0,1,6,6,0,1,6,6, },
      { 7,7,7,6,6,0,1,6,6,0,1,6,6, },
      { 7,7,7,6,6,0,1,6,6,0,1,6,6, },
      { 7,7,7,6,6,2,3,6,6,2,3,6,6, },
      { 7,7,7,6,6,4,5,6,6,4,5,6,6, },
      { 7,7,7,6,6,4,5,6,6,4,5,6,6, },
      { 7,7,7,6,6,4,5,6,6,4,5,6,6, },
      { 7,7,7,6,6,4,5,6,6,4,5,6,6, },
      { 7,7,7,6,6,4,5,6,6,4,5,6,6, },
      { 7,7,7,6,6,4,5,6,6,4,5,6,6, },
      { 7,7,7,6,6,4,5,6,6,4,5,6,6, },
      { 7,7,7,6,6,4,5,6,6,4,5,6,6, },
      { 7,7,7,6,6,4,5,6,6,4,5,6,6, },
      { 7,7,7,6,6,4,5,6,6,4,5,6,6, },
      { 7,7,7,6,6,4,5,6,6,4,5,6,6, },
    },
  },
};
