/* XBlast 2.5.3 level */
static BMLevelData Bricklayer =
{
  /* BMLevel */
  {
    "Bricklayer's Anger",
    "Markus Schreiber",
    "xblast.useBricklayer",
    "Keep an eye on disappearing bricks",
    GM_Random | GM_23456_Player | GM_All,
    (void *) &Bricklayer,
    NULL,
  },
  /* BMShrinkData */
  {
    shrink_spiral,
    SCRAMBLE_VOID,
    SCRAMBLE_VOID,
  },
  /* BMFuncData */
  {
    special_init_special_bombs_30,
    special_game_void,
    special_extra_void,
    special_key_special_bomb,
  },
  /* BMPlayerData */
  {
    7, 9,
    {
      {  1,  1 },
      {  1, 13 },
      { 11, 13 },
      { 11,  1 },
      {  1,  7 },
      { 11,  7 },
    },
    PM_Same, 2,
    Healthy, Healthy, IF_Kick,
  },
  /* BMBombData */
  {
    bomb_click_none, bomb_click_none, bomb_click_none,
    GoStop, FUSEnormal,
    BMTnormal, BMTdestruction, BMTnormal,
  },
  /* BMGraphicsData */
  {
    {
      { "iron_floor", "Black", "IndianRed", "Yellow" },
      { "iron_floor_S", "Black", "IndianRed", "Yellow" },
      { "bricks", "Black", "SlateBlue", "Cyan" },
      { "bricks", "Black", "SlateBlue", "LightSlateBlue" },
      { "bricks", "Black", "SaddleBrown", "Black" },
      { "bricks", "Black", "SaddleBrown", "Black" },
      EXTRA_BOMB,
      EXTRA_RANGE,
      EXTRA_TRAP,
      EXTRA_NAPALM,
      { "score_floor", "RoyalBlue", "RoyalBlue", "RoyalBlue" },
    },
  },
  /* BMMapData */
  {
    ShadowBlock, DEnone,
    { 0, 0, 0, 0, 0 },
    {
      { B,B,B,B,B,B,B,B,B,B,B,B,B, },
      { B,_,_,B,_,_,B,_,_,B,_,_,B, },
      { B,_,B,_,_,_,B,_,_,_,B,_,B, },
      { B,B,_,B,B,B,_,B,B,B,_,B,B, },
      { B,_,B,_,B,_,B,_,B,_,B,_,B, },
      { B,B,_,B,_,B,_,B,_,B,_,B,B, },
      { B,_,B,B,_,B,_,B,_,B,B,_,B, },
      { B,_,_,B,B,_,B,_,B,B,_,_,B, },
      { B,_,B,B,_,B,_,B,_,B,B,_,B, },
      { B,B,_,B,_,B,_,B,_,B,_,B,B, },
      { B,_,B,_,B,_,B,_,B,_,B,_,B, },
      { B,B,_,B,B,B,_,B,B,B,_,B,B, },
      { B,_,B,_,_,_,B,_,_,_,B,_,B, },
      { B,_,_,B,_,_,B,_,_,B,_,_,B, },
      { B,B,B,B,B,B,B,B,B,B,B,B,B, },
    },
  },
};
