/* XBlast 2.6.beta level
 * Level created by Storch 1.00
 * Written by Tobias Johansson (d97tj@efd.lth.se)
 * "Creeping Death" is created by Daniel Schobben, april '98
 */

static BMLevelData CreepingDeath =
{
  /* BMLevel */
  {
    "Creeping Death",
    "Daniel Schobben",
    "xblast.useCreepingDeath",
    "Die by my hand...",
    GM_Random | GM_23456_Player | GM_All,
    (void *) &CreepingDeath,
    NULL,
  },
  /* BMShrinkData */
  {
    shrink_void,
    SCRAMBLE_VOID,
    SCRAMBLE_VOID,
  },
  /* BMFuncData */
  {
  special_init_void,
  special_game_void,
  special_extra_cloak,
  special_key_cloak,
  },
  /* BMPlayerData */
  {
    7, 4,
    {
      { 7, 6 },
      { 7, 6 },
      { 7, 6 },
      { 7, 6 },
      { 7, 6 },
      { 7, 6 },
    },
    PM_Polar, 2,
    Healthy, Healthy, IF_Kick,
  },
  /* BMBombData */
  {
    bomb_click_snooker, bomb_click_none, bomb_click_none,
    GoStop, FUSElong,
    BMTnormal, BMTnormal, BMTnormal,
  },
  /* BMGraphicsData */
  {
    {
      { "bomb_floor", NULL, "SteelBlue",  "DarkSlateGray" },
      { "bomb_floor", NULL, "SteelBlue",  "DarkSlateGray" },
      { "dark_block",     "Black", "SeaGreen", "NavyBlue" },
      { "dark_block_R", "Black", "NavyBlue", "SeaGreen" },
      { "extra",         "Black", "Gray50", "White" },
      { "extra_O",       "Black", "Gray50", "White" },
      EXTRA_BOMB,
      EXTRA_RANGE,
      EXTRA_TRAP,
      EXTRA_CLOAK,
      { "score_floor",    "Black", "Gray50", "White" },
    },
  },
  /* BMMapData */
  {
      ShadowFull, DEspecial,
      { 15, 30, 30, 45, 60 },
      {
      { B,B,B,B,B,B,B,B,B,B,B,B,B, },
      { B,_,_,_,_,_,_,_,_,_,_,_,B, },
      { B,_,_,_,_,_,B,B,B,_,_,_,B, },
      { B,_,_,_,B,_,_,B,_,_,X,_,B, },
      { B,_,_,B,_,_,_,_,_,X,_,B,B, },
      { B,_,B,_,_,_,_,B,_,B,_,_,B, },
      { B,_,_,_,_,X,B,_,B,_,B,_,B, },
      { B,_,q,_,X,X,_,_,_,_,_,_,B, },
      { B,_,_,_,_,X,B,_,B,_,B,_,B, },
      { B,_,B,_,_,_,_,B,_,B,_,_,B, },
      { B,_,_,B,_,_,_,_,_,X,_,B,B, },
      { B,_,_,_,B,_,_,B,_,_,X,_,B, },
      { B,_,_,_,_,_,B,B,B,_,_,_,B, },
      { B,_,_,_,_,_,_,_,_,_,_,_,B, },
      { B,B,B,B,B,B,B,B,B,B,B,B,B, },
    },
  },
};
