/* XBlast 2.5.3 level */
/* File: level/Bomb_Surprise.h */
/* Author: Stephan Natschlaeger */
/* Version: 16.12.1997 */
static BMLevelData Bomb_Surprise =
{
  /* BMLevel */
  {
    "Bomb A La Surprise",
    "Stn",
    "xblast.useBomb_Surprise",
    "Watch For Hidden Bombs",
    GM_Random | GM_234_Player | GM_All,
    (void *) &Bomb_Surprise,
    NULL,
  },
  /* BMShrinkData */
  {
    shrink_constrict_wave,
    SCRAMBLE_VOID,
    SCRAMBLE_VOID,
  },
  /* BMFuncData */
  {
    special_init_void,
    special_game_void,
    special_extra_kick,
    special_key_void,
  },
  /* BMPlayerData */
  {
    1, 2,
    {
      {  2,  1 },
      {  2, 13 },
      { 10, 13 },
      { 10,  1 },
      {  5,  7 },
      {  9,  9 },
    },
    PM_Same, 0,
    Healthy, Healthy, IF_None,
  },
  /* BMBombData */
  {
    bomb_click_snooker, bomb_click_randomdir, bomb_click_none,
    GoStop, FUSEnormal,
    BMTnormal, BMTnormal, BMTrandom,
  },
  /* BMGraphicsData */
  {
    {
      { "lego_floor", "Black", "RoyalBlue", "RoyalBlue" },
      { "lego_floor_S", "Black", "RoyalBlue", "RoyalBlue" },
      { "lego_white", "Black", "Yellow", "RoyalBlue" },
      { "lego_black", "LightYellow", "Black", "RoyalBlue" },
      { "lego_black", "White", "Black", "RoyalBlue" },
      { "lego_black_O", "White", "Black", "RoyalBlue" },
      EXTRA_BOMB,
      EXTRA_RANGE,
      EXTRA_TRAP,
      EXTRA_KICK,
      { "score_floor", "RoyalBlue", "RoyalBlue", "RoyalBlue" },
    },
  },
  /* BMMapData */
  {
    ShadowFull, DEall,
    { 10, 15, 15, 15, 60 },
    {
      { B,B,B,B,B,B,B,B,B,B,B,B,B, },
      { B,X,_,_,_,s,r,X,_,_,_,X,B, },
      { B,r,X,B,_,X,B,s,_,B,X,r,B, },
      { B,q,B,_,B,_,B,_,B,_,B,q,B, },
      { B,s,_,b,s,_,r,_,s,b,_,b,B, },
      { B,X,B,_,B,_,X,_,B,_,B,X,B, },
      { B,_,_,_,_,r,B,X,_,_,_,_,B, },
      { B,B,B,X,B,_,_,_,B,X,B,B,B, },
      { B,_,_,_,_,X,B,r,_,_,_,_,B, },
      { B,X,B,_,B,_,X,_,B,_,B,X,B, },
      { B,s,_,b,s,_,r,_,s,b,_,b,B, },
      { B,q,B,_,B,_,B,_,B,_,B,q,B, },
      { B,r,X,B,_,s,B,X,_,B,X,r,B, },
      { B,X,_,_,_,X,r,s,_,_,_,X,B, },
      { B,B,B,B,B,B,B,B,B,B,B,B,B, },
    },
  },
};
