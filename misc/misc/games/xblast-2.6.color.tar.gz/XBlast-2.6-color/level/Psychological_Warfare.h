/* XBlast 2.5.3 level */
static BMLevelData Psychological_Warfare =
{
  /* BMLevel */
  {
    "Psychological Warfare",
    "The Adelaide Group",
    "xblast.usePsychologicalWarfare",
    "It's very easy to get crushed by the shrink in this level.",
    GM_Random | GM_234_Player | GM_SinglePlayer,
    (void *) &Psychological_Warfare,
    NULL,
  },
  /* BMShrinkData */
  {
    shrink_compound,
    SCRAMBLE_VOID,
    SCRAMBLE_VOID,
  },
  /* BMFuncData */
  {
    special_init_void,
    special_game_void,
    special_extra_speed,
    special_key_cloak,
  },
  /* BMPlayerData */
  {
    1, 5,
    {
      {  1,  1 },
      {  1, 13 },
      { 11, 13 },
      { 11,  1 },
    },
    PM_Polar, 2,
    Healthy, Healthy, IF_Cloak,
  },
  /* BMBombData */
  {
    bomb_click_none, bomb_click_none, bomb_click_none,
    GoStop, FUSEnormal,
    BMTnormal, BMTnormal, BMTnormal,
  },
  /* BMGraphicsData */
  {
    {
      { "chess_floor",    "Black", "Turquoise", "Gray50" },
      { "chess_floor_S",  "Black", "Turquoise", "Gray50" },
      { "wall",          "Black", "BlueViolet", "VioletRed" },
      { "wall",          "Black", "BlueViolet", "VioletRed" },
      { "chess_sphere",   "Black", "Turquoise", "GreenYellow" },
      { "chess_sphere_O", "Black", "Turquoise", "GreenYellow" },
      EXTRA_BOMB,
      EXTRA_RANGE,
      EXTRA_TRAP,
      EXTRA_SPEED,
      { "check",        "Black", "White", "Gray50" },
    },
  },
  /* BMMapData */
  {
    ShadowBlock, DEall,
    { 15, 39, 47, 47, 47},
    {
      { B,B,B,B,B,B,B,B,B,B,B,B,B },
      { B,_,_,_,X,_,X,_,X,_,_,_,B },
      { B,_,B,X,B,X,B,X,B,X,B,_,B },
      { B,_,X,_,X,_,X,_,X,_,X,_,B },
      { B,X,B,X,B,X,B,X,B,X,B,X,B },
      { B,_,X,q,_,_,_,_,_,q,X,_,B },
      { B,X,B,_,B,X,X,X,B,_,B,X,B },
      { B,_,X,_,_,X,B,X,_,_,X,_,B },
      { B,X,B,_,B,X,X,X,B,_,B,X,B },
      { B,_,X,q,_,_,_,_,_,q,X,_,B },
      { B,X,B,X,B,X,B,X,B,X,B,X,B },
      { B,_,X,_,X,_,X,_,X,_,X,_,B },
      { B,_,B,X,B,X,B,X,B,X,B,_,B },
      { B,_,_,_,X,_,X,_,X,_,_,_,B },
      { B,B,B,B,B,B,B,B,B,B,B,B,B }    
    },
  },
};


