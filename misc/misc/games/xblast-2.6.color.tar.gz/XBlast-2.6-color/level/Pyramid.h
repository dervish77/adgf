/* XBlast 2.5.3 level */
/* File: level/Pyramid.h */
/* Author: Stephan Natschlaeger */
/* Version: 7.1.1998 */
static BMLevelData Pyramid =
{
  /* BMLevel */
  {
    "Pyramid",
    "Stn",
    "xblast.usePyramid",
    "Walk Like An Egyptian",
    GM_Random | GM_23456_Player | GM_All,
    (void *) &Pyramid,
    NULL,
  },
  /* BMShrinkData */
  {
    shrink_spiral,
    SCRAMBLE_VOID,
    SCRAMBLE_VOID,
  },
  /* BMFuncData */
  {
    special_init_special_bombs_30,
    special_game_void,
    special_extra_special_bomb,
    special_key_special_bomb,
  },
  /* BMPlayerData */
  {
    1, 1,
    {
      {  6,  6 },
      {  6,  8 },
      { 11,  3 },
      { 11, 11 },
      { 10,  5 },
      { 10,  9 },
    },
    PM_Same, 0,
    Healthy, Healthy, IF_Kick,
  },
  /* BMBombData */
  {
    bomb_click_none, bomb_click_none, bomb_click_none,
    GoStop, FUSEnormal,
    BMTnormal, BMTfungus, BMTfungus,
  },
  /* BMGraphicsData */
  {
    {
      { "iron_floor", "Black", "PaleGoldenRod", "Blue" },
      { "iron_floor_S", "Black", "PaleGoldenRod", "Blue" },
      { "dark_block", "Black", "ForestGreen", "Gray80" },
      { "dark_block_R", "Black", "SpringGreen", "White" },
      { "extra", "Black", "Firebrick", "Black" },
      { "extra", "Black", "Firebrick", "Black" },
      EXTRA_BOMB,
      EXTRA_RANGE,
      EXTRA_TRAP,
      EXTRA_KICK,
      { "score_floor", "SteelBlue", "SteelBlue", "RoyalBlue" },
    },
  },
  /* BMMapData */
  {
    ShadowExtra, DEall,
    { 20, 40, 60, 60, 60 },
    {
      { B,B,B,B,B,B,B,B,B,B,B,B,B, },
      { B,B,B,B,X,_,_,_,_,_,_,B,B, },
      { B,B,B,X,_,_,_,_,_,_,X,_,B, },
      { B,B,X,_,_,_,_,_,B,X,_,_,B, },
      { B,X,_,_,_,_,B,X,X,X,X,B,B, },
      { B,_,_,_,X,X,_,X,X,X,_,_,B, },
      { B,_,_,B,X,_,_,X,B,X,_,X,B, },
      { B,B,X,X,X,X,B,X,X,X,X,B,B, },
      { B,_,_,B,X,_,_,X,B,X,_,X,B, },
      { B,_,_,_,X,X,_,X,X,X,_,_,B, },
      { B,X,_,_,_,_,B,X,X,X,X,B,B, },
      { B,B,X,_,_,_,_,_,B,X,_,_,B, },
      { B,B,B,X,_,_,_,_,_,_,X,_,B, },
      { B,B,B,B,X,_,_,_,_,_,_,B,B, },
      { B,B,B,B,B,B,B,B,B,B,B,B,B, },
    },
  },
};
