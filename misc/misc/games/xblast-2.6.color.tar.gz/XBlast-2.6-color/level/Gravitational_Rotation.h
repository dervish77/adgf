/* XBlast 2.5.3 level */
/* File: level/Gravitational_Rotation.h */
/* Author: Stephan Natschlaeger */
/* Version: 16.12.1997 */
static BMLevelData Gravitational_Rotation=
{
  /* BMLevel */
  {
    "Gravitational Rotation",
    "Stn",
    "xblast.useGravitationalRotation",
    "Fallen Bombgs Will Not Stay Down",
    GM_Random | GM_23456_Player | GM_All,
    (void *) &Gravitational_Rotation,
    NULL,
  },
  /* BMShrinkData */
  {
    shrink_void,
    SCRAMBLE_VOID,
    SCRAMBLE_VOID,
  },
  /* BMFuncData */
  {
    special_init_void,
    special_game_void,
    special_extra_void,
    special_key_void,
  },
  /* BMPlayerData */
  {
    5, 25,
    {
      {  1,  1 },
      {  3,  1 },
      {  5,  1 },
      {  7,  1 },
      {  9,  1 },
      { 11,  1 },
    },
    PM_Same, 0,
    Healthy, Healthy, IF_None,
  },
  /* BMBombData */
  {
    bomb_click_none, bomb_click_anticlockwise, bomb_click_none,
    GoDown, FUSElong,
    BMTnormal, BMTnormal, BMTnormal,
  },
  /* BMGraphicsData */
  {
    {
      { "karo_light",   "Black", "SlateBlue", "SteelBlue" },
      { "karo_light_S", "Black", "SlateBlue", "SteelBlue" },
      { "pyramid",     "Black", "Goldenrod", "Goldenrod" },
      { "pyramid_R", "Black", "Goldenrod", "LightGoldenrod" },
      { "extra",       "Black", "Sienna",    "Orange" },
      { "extra_O",     "Black", "Sienna",    "Orange" },
      EXTRA_BOMB,
      EXTRA_RANGE,
      EXTRA_TRAP,
      EXTRA_KICK,
      { "karo_light",   "Black", "SlateBlue", "SteelBlue" },
    },
  },
  /* BMMapData */
  {
    ShadowFull, DEall,
    { 16, 48, 48, 60, 60 },
    {
      { B,B,B,B,B,B,B,B,B,B,B,B,B, },
      { B,_,_,_,_,_,_,_,_,_,_,_,B, },
      { B,_,B,_,B,_,B,_,B,_,B,_,B, },
      { B,_,_,_,_,_,_,_,_,_,_,_,B, },
      { B,_,B,_,B,_,B,_,B,_,B,_,B, },
      { B,_,_,_,_,_,_,_,_,_,_,_,B, },
      { B,_,_,_,_,_,_,_,_,_,_,_,B, },
      { B,_,B,_,B,_,B,_,B,_,B,_,B, },
      { B,_,_,_,_,_,_,_,_,_,_,_,B, },
      { B,_,_,_,_,_,_,_,_,_,_,_,B, },
      { B,_,B,_,B,_,B,_,B,_,B,_,B, },
      { B,_,_,_,_,_,_,_,_,_,_,_,B, },
      { B,_,B,_,B,_,B,_,B,_,B,_,B, },
      { B,_,_,_,_,_,_,_,_,_,_,_,B, },
      { B,B,B,B,B,B,B,B,B,B,B,B,B, },
    },
  },
};
