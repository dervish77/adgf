/* XBlast 2.5.3 level */
static BMPosition SplitDecision_Dele[] = {
 {7,5},{7,6},{7,7},{7,8},{7,9},{5,5},{5,6},{5,7},{5,8},{5,9},{6,5},{6,9},{7,4},
 {7,10},{6,4},{6,10},{5,4},{5,10},{8,6},{8,7},{8,8},{4,6},{4,7},{4,8},
 {9,6},{9,7},{9,8},{3,6},{3,7},{3,8},{2,7},{10,7},{6,2},{6,3},{6,12},{6,11},
 {8,5},{8,9},{4,5},{4,9} };

static BMPosition SplitDecision_Draw[] = { 
  {1,1},{2,1},{3,1},{4,1},{5,1},{6,1},{7,1},{8,1},{9,1},{10,1},{11,1}, 
  {1,13},{2,13},{3,13},{4,13},{5,13},{6,13},{7,13},{8,13},{9,13},{10,13},
  {11,13},{1,2},{1,3},{1,4},{1,5},{1,6},{1,7},{1,8},{1,9},{1,10},{1,11},{1,12}, 
  {11,2},{11,3},{11,4},{11,5},{11,6},{11,7},{11,8},{11,9},{11,10},{11,11},
  {11,12},{6,7},{6,2},{6,12} };
 
static BMLevelData SplitDecision =
{
  /* BMLevel */
  {
    "Split Decision",
    "Keith Gillow",
    "xblast.useSplitDecision",
    "Make a choice and take a chance",
    GM_Random | GM_23456_Player | GM_All,
    (void *) &SplitDecision,
    NULL,
  },
  /* BMShrinkData */
  {
    shrink_outward_spiral,
    {5*GAME_TIME/8, 47, SplitDecision_Draw}, 
    {GAME_TIME/2, 40, SplitDecision_Dele},
  },
  /* BMFuncData */
  {
    special_init_special_bombs_30,
    special_game_void,
    special_extra_void,
    special_key_special_bomb,
  },
  /* BMPlayerData */
  {
    3, 4,
    {
      {  1,  1 },
      {  1, 13 },
      { 11, 13 },
      { 11,  1 },
      {  6,  6 },
      {  6,  8 },
    },
    PM_Inner, 4,
    Healthy, Healthy, IF_Kick,
  },
  /* BMBombData */
  {
    bomb_click_none, bomb_click_anticlockwise, bomb_click_none,
    GoStop, FUSEnormal,
    BMTnormal, BMTgrenade, BMTnormal,
  },
  /* BMGraphicsData */
  {
    {
      { "rock_floor",   "Black", "blue", "green" },
      { "rock_floor_S", "Black", "blue", "green" },
      { "weight",      "Black", "yellow", "red" },
      { "weight_R",  "Black", "cyan", "plum" },
      { "bricks",      "Black", "OliveDrab", "Black" },
      { "brick_O",    "Black", "OliveDrab", "Black" },
      EXTRA_BOMB,
      EXTRA_RANGE,
      EXTRA_TRAP,
      { "score_floor", "RoyalBlue", "RoyalBlue", "RoyalBlue" },
      { "score_floor", "RoyalBlue", "RoyalBlue", "RoyalBlue" },
    },
  },
  /* BMMapData */
  {
    ShadowBlock, DEnone,
    { 0, 0, 0, 0, 0 },
    {
      { B,B,B,B,B,B,B,B,B,B,B,B,B, },
      { B,_,_,_,_,_,_,_,_,_,_,_,B, },
      { B,_,_,_,_,_,_,_,_,_,_,_,B, },
      { B,_,_,_,_,_,_,_,_,_,_,_,B, },
      { B,_,_,_,_,_,_,_,_,_,_,_,B, },
      { B,_,_,_,_,_,_,_,_,_,_,_,B, },
      { B,_,_,_,_,_,_,_,_,_,_,_,B, },
      { B,_,_,_,_,_,_,_,_,_,_,_,B, },
      { B,_,_,_,_,_,_,_,_,_,_,_,B, },
      { B,_,_,_,_,_,_,_,_,_,_,_,B, },
      { B,_,_,_,_,_,_,_,_,_,_,_,B, },
      { B,_,_,_,_,_,_,_,_,_,_,_,B, },
      { B,_,_,_,_,_,_,_,_,_,_,_,B, },
      { B,_,_,_,_,_,_,_,_,_,_,_,B, },
      { B,B,B,B,B,B,B,B,B,B,B,B,B, },
    },
  },
};
