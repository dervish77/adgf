/* XBlast 2.5.3 level */
static BMLevelData TotalControl =
{
  /* BMLevel */
  {
    "Out of Control",
    "Peel & Killer",
    "xblast.useTotalControl",
    "There can only be one Master",
    GM_Random | GM_234_Player | GM_All,
    (void *) &TotalControl,
    NULL,
  },
  /* BMShrinkData */
  {
    shrink_spiral_3,
    SCRAMBLE_VOID,
    SCRAMBLE_VOID,
  },
  /* BMFuncData */
  {
    special_init_void,
    special_game_void,
    special_extra_RC,
    special_key_RC,
  },
  /* BMPlayerData */
  {
    1, 4,
    {
      { 1, 1 },
      { 1, 13 },
      { 11, 13 },
      { 11, 1 },
    },
    PM_Polar, 2,
    Healthy, Healthy, IF_Kick,
  },
  /* BMBombData */
  {
    bomb_click_randomdir, bomb_click_randomdir, bomb_click_randomdir,
    GoStop, FUSEnormal,
    BMTnormal, BMTnormal, BMTnormal,
  },
  /* BMGraphicsData */
  {
    {
      { "iron_floor", "Black", "Red", "White" },
      { "iron_floor_S", "Black", "Red", "White" },
      { "dark_block", "Black", "Yellow", "DarkTurquoise" },
      { "dark_block_R", "Black", "Yellow", "DarkTurquoise" },
      { "bricks", "Black", "Red", "Gray80" },
      { "brick_O", "Black", "Red", "Gray80" },
      EXTRA_BOMB,
      EXTRA_RANGE,
      EXTRA_TRAP,
      EXTRA_RC,
      { "score_floor", "Red", "Red", "RoyalBlue" },
    },
  },
  /* BMMapData */
  {
    ShadowFull, DEsingle,
    {16,32,48,48,56},
    {
      { B,B,B,B,B,B,B,B,B,B,B,B,B, },
      { B,_,_,s,X,b,r,b,X,s,_,_,B, },
      { B,_,X,B,B,B,X,B,B,B,X,_,B, },
      { B,s,B,s,s,_,_,_,s,s,B,s,B, },
      { B,s,B,s,B,_,_,_,B,s,B,s,B, },
      { B,X,B,_,_,_,B,_,_,_,B,X,B, },
      { B,b,B,_,_,s,X,s,_,_,B,b,B, },
      { B,r,X,_,B,X,q,X,B,_,X,r,B, },
      { B,b,B,_,_,s,X,s,_,_,B,b,B, },
      { B,X,B,_,_,_,B,_,_,_,B,X,B, },
      { B,s,B,s,B,_,_,_,B,s,B,s,B, },
      { B,s,B,s,s,_,_,_,s,s,B,s,B, },
      { B,_,X,B,B,B,X,B,B,B,X,_,B, },
      { B,_,_,s,X,b,r,b,X,s,_,_,B, },
      { B,B,B,B,B,B,B,B,B,B,B,B,B, },
    },
  },
};

