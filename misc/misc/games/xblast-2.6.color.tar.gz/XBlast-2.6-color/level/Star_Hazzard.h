/* XBlast 2.5.3 level */
static BMLevelData StarHazzard =
{
  /* BMLevel */
  {
    "Star Hazzard",
    "Thomas CORNET",
    "xblast.useStarHazzard",
    "Be lucky",
    GM_Random | GM_23456_Player | GM_All,
    (void *) &StarHazzard,
    NULL,
  },
  /* BMShrinkData */
  {
    shrink_void,
    SCRAMBLE_VOID,
    SCRAMBLE_VOID,
  },
  /* BMFuncData */
  {
    special_init_special_bombs_30,
    special_game_void,
    special_extra_invincible,
    special_key_special_bomb,
  },
  /* BMPlayerData */
  {
    5, 9,
    {
      {  1,  1 },
      { 11,  1 },
      {  1, 13 },
      { 11, 13 },
      {  4,  7 },
      {  8,  7 },
    },
    PM_Polar, 3,
    Healthy, Healthy, IF_Kick,
  },
  /* BMBombData */
  {
    bomb_click_snooker, bomb_click_none, bomb_click_none,
    GoStop, FUSEnormal,
    BMTnormal, BMTblastnow, BMTnormal,
  },
  /* BMGraphicsData */
  {
    {
      { "iron_floor", "Black", "IndianRed", "Yellow" },
      { "iron_floor_S", "Black", "IndianRed", "Yellow" },
      { "dark_block", "Black", "SlateBlue", "Cyan" },
      { "dark_block_R", "Black", "SlateBlue", "LightSlateBlue" },
      { "extra", "Black", "SaddleBrown", "Black" },
      { "extra", "Black", "SaddleBrown", "Black" },
      EXTRA_BOMB,
      EXTRA_RANGE,
      EXTRA_TRAP,
      EXTRA_INVINC,
      { "score_floor", "RoyalBlue", "RoyalBlue", "RoyalBlue" },
    },
  },
  /* BMMapData */
  {
    ShadowBlock, DEnone,
    { 9, 20, 20, 70, 80 },
    {
      { B,B,B,B,B,B,B,B,B,B,B,B,B, },
      { B,_,_,X,_,_,X,_,_,X,_,_,B, },
      { B,_,B,B,_,_,X,_,_,B,B,_,B, },
      { B,X,B,_,_,X,_,X,_,_,B,X,B, },
      { B,_,_,_,X,_,X,_,X,_,_,_,B, },
      { B,_,_,X,_,_,X,_,_,X,_,_,B, },
      { B,_,X,_,_,q,B,q,_,_,X,_,B, },
      { B,X,_,X,_,B,B,B,_,X,_,X,B, },
      { B,_,X,_,_,q,B,q,_,_,X,_,B, },
      { B,_,_,X,_,_,X,_,_,X,_,_,B, },
      { B,_,_,_,X,_,X,_,X,_,_,_,B, },
      { B,X,B,_,_,X,_,X,_,_,B,X,B, },
      { B,_,B,B,_,_,X,_,_,B,B,_,B, },
      { B,_,_,X,_,_,X,_,_,X,_,_,B, },
      { B,B,B,B,B,B,B,B,B,B,B,B,B, },
    },
  },
};
