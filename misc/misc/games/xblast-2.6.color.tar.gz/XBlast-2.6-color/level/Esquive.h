/* XBlast 2.5.3 level */
static BMLevelData Esquive =
{
  /* BMLevel */
  {
    "Tous aux abris !",
    "Thomas CORNET",
    "xblast.useEsquive",
    "Rapidite et maitrise.",
    GM_Random | GM_23456_Player | GM_All,
    (void *) &Esquive,
    NULL,
  },
  /* BMShrinkData */
  {
    shrink_quad,
    SCRAMBLE_VOID,
    SCRAMBLE_VOID,
  },
  /* BMFuncData */
  {
    special_init_void,
    special_game_void,
    special_extra_void,
    special_key_RC,
  },
  /* BMPlayerData */
  {
    2, 3,
    {
      {  1,  1 },
      {  1, 13 },
      { 11,  1 },
      { 11, 13 },
      {  7,  5 },
      {  5,  9 },
    },
    PM_Circle, -1,
    IllRun, IllRun, IF_RC | IF_Kick,
  },
  /* BMBombData */
  {
    bomb_click_none, bomb_click_none, bomb_click_none,
    GoStop, FUSEnormal,
    BMTnormal, BMTnormal, BMTnormal,
  },
  /* BMGraphicsData */
  {
    {    
      { "dark_way", "Black", "Green", "Gray80" },
      { "dark_way_S", "Black", "Green", "Gray80" },
      { "r_i_p", "Black", "Gray60", "Green" },
      { "r_i_p_R", "Black", "Gray60", "Green" },
      { "pumpkin", "Black", "Goldenrod", "Green" },
      { "pumpkin_O", "Black", "Goldenrod", "Green" },
      EXTRA_BOMB,
      EXTRA_RANGE,
      EXTRA_TRAP,
      EXTRA_BUTTON,
      { "score_floor", "Black", "Black", "RoyalBlue" },    
    },
  },
  /* BMMapData */
  {
    ShadowNone, DEsingle,
    { 0, 0, 0, 0, 0 },
    {
      { B,B,B,B,B,B,B,B,B,B,B,B,B, },
      { B,_,_,_,_,_,_,_,_,_,_,_,B, },
      { B,_,B,_,B,_,B,_,B,_,B,_,B, },
      { B,_,_,_,_,_,_,_,_,_,_,_,B, },
      { B,_,B,_,B,_,B,_,B,_,B,_,B, },
      { B,_,_,_,_,_,_,_,_,_,_,_,B, },
      { B,_,B,_,B,_,B,_,B,_,B,_,B, },
      { B,_,_,_,_,_,_,_,_,_,_,_,B, },
      { B,_,B,_,B,_,B,_,B,_,B,_,B, },
      { B,_,_,_,_,_,_,_,_,_,_,_,B, },
      { B,_,B,_,B,_,B,_,B,_,B,_,B, },
      { B,_,_,_,_,_,_,_,_,_,_,_,B, },
      { B,_,B,_,B,_,B,_,B,_,B,_,B, },
      { B,_,_,_,_,_,_,_,_,_,_,_,B, },
      { B,B,B,B,B,B,B,B,B,B,B,B,B, },
    },
  },
};
