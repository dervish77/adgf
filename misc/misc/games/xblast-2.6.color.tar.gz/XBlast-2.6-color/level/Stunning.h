/* XBlast 2.5.3 level */
static BMLevelData Stunning =
{
  /* BMLevel */
  {
    "Stunning",
    "Oliver Vogel",
    "xblast.useStunning",
    "Stun them, trap them, blast them",
    GM_Random | GM_23456_Player | GM_All,
    (void *) &Stunning,
    NULL,
  },
  /* BMShrinkData */
  {
    shrink_spiral,
    SCRAMBLE_VOID,
    SCRAMBLE_VOID,
  },
  /* BMFuncData */
  {
    special_init_void,
    special_game_void,
    special_extra_stun_others,
    special_key_void,
  },
  /* BMPlayerData */
  {
    1, 2,
    {
      {  1,  1 },
      {  1, 13 },
      { 11, 13 },
      { 11,  1 },
      {  1,  7 },
      { 11,  7 },
    },
    PM_Inner, 0,
    Healthy, Healthy, IF_None,
  },
  /* BMBombData */
  {
    bomb_click_none, bomb_click_none, bomb_click_thru,
    GoStop, FUSEnormal,
    BMTnormal, BMTnormal, BMTnormal,
  },
  /* BMGraphicsData */
  {
    {
      { "mr_beam_free",   "Black", "DarkKhaki", "Black" },
      { "mr_beam_free",   "Black", "DarkKhaki", "Black" },
      { "weight",         "Black", "Red",   "RoyalBlue" },
      { "weight_R",       "Black", "Red",   "RoyalBlue" },
      { "mr_beam_bear",       "Black", "DarkKhaki",  "SpringGreen" },
      { "mr_beam_bear_O",      "Black", "DarkKhaki", "SpringGreen" },
      EXTRA_BOMB,
      EXTRA_RANGE,
      EXTRA_TRAP,
      EXTRA_POW,
      { "score_floor", "RoyalBlue", "RoyalBlue", "RoyalBlue" },
    },
  },
  /* BMMapData */
  {
    ShadowBlock, DEdouble,
    { 32, 36, 36, 52, 56 },
    {
      { B,B,B,B,B,B,B,B,B,B,B,B,B, },
      { B,_,_,_,_,_,_,_,_,_,_,_,B, },
      { B,_,B,B,X,B,X,B,X,B,B,_,B, },
      { B,_,X,_,X,_,X,_,X,_,X,_,B, },
      { B,_,B,_,B,_,B,_,B,_,B,_,B, },
      { B,_,B,X,B,X,B,X,B,X,B,_,B, },
      { B,_,X,_,X,_,X,_,X,_,X,_,B, },
      { B,_,B,B,X,B,X,B,X,B,B,_,B, },
      { B,_,X,_,X,_,X,_,X,_,X,_,B, },
      { B,_,B,_,B,_,B,_,B,_,B,_,B, },
      { B,_,B,X,B,X,B,X,B,X,B,_,B, },
      { B,_,X,_,X,_,X,_,X,_,X,_,B, },
      { B,_,B,B,X,B,X,B,X,B,B,_,B, },
      { B,_,_,_,_,_,_,_,_,_,_,_,B, },
      { B,B,B,B,B,B,B,B,B,B,B,B,B, },
    },
  },
};
