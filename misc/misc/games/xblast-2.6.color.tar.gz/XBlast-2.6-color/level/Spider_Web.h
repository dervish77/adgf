/* XBlast 2.5.3 level */
/* File: level/Spider_Web.h */
/* Author: Stephan Natschlaeger */
/* Version: 16.12.1997 */
static BMLevelData Spider_Web =
{
  /* BMLevel */
  {
    "Spider Web",
    "Stn",
    "xblast.useSpiderWeb",
    "The Best Is In The Middle",
    GM_Random | GM_234_Player | GM_All,
    (void *) &Spider_Web,
    NULL,
  },
  /* BMShrinkData */
  {
    shrink_void,
    SCRAMBLE_VOID,
    SCRAMBLE_VOID,
  },
  /* BMFuncData */
  {
    special_init_void,
    special_game_void,
    special_extra_RC,
    special_key_RC,
  },
  /* BMPlayerData */
  {
    3, 4,
    {
      {  6,  1 },
      {  6, 13 },
      {  1,  7 },
      { 11,  7 },
      {  1,  7 },
      { 11,  7 },
    },
    PM_Same, 0,
    Healthy, Healthy, IF_None,
  },
  /* BMBombData */
  {
    bomb_click_none, bomb_click_none, bomb_click_none,
    GoStop, FUSElong,
    BMTnormal, BMTnormal, BMTnormal,
  },
  /* BMGraphicsData */
  {
    {
      { "karo_light",   "Black", "SlateBlue", "SteelBlue" },
      { "karo_light_S", "Black", "SlateBlue", "SteelBlue" },
      { "pyramid",     "Black", "Goldenrod", "Goldenrod" },
      { "pyramid_R", "Black", "Goldenrod", "LightGoldenrod" },
      { "extra",       "Black", "Sienna",    "Orange" },
      { "extra_O",     "Black", "Sienna",    "Orange" },
      EXTRA_BOMB,
      EXTRA_RANGE,
      EXTRA_TRAP,
      EXTRA_RC,
      { "score_floor", "RoyalBlue", "RoyalBlue", "RoyalBlue" },
    },
  },
  /* BMMapData */
  {
    ShadowFull, DEall,
    {  1, 35, 47, 47, 47 },
    {
      { B,B,B,B,B,B,B,B,B,B,B,B,B, },
      { B,B,B,B,X,_,_,_,X,B,B,B,B, },
      { B,B,B,_,X,B,_,B,X,_,B,B,B, },
      { B,B,X,X,B,_,X,_,B,X,X,B,B, },
      { B,B,_,B,_,X,_,X,_,B,_,B,B, },
      { B,X,X,B,_,B,X,B,_,B,X,X,B, },
      { B,_,B,_,X,B,_,B,X,_,B,_,B, },
      { B,_,_,X,X,_,q,_,X,X,_,_,B, },
      { B,_,B,_,X,B,_,B,X,_,B,_,B, },
      { B,X,X,B,_,B,X,B,_,B,X,X,B, },
      { B,B,_,B,_,X,_,X,_,B,_,B,B, },
      { B,B,X,X,B,_,X,_,B,X,X,B,B, },
      { B,B,B,_,X,B,_,B,X,_,B,B,B, },
      { B,B,B,B,X,_,_,_,X,B,B,B,B, },
      { B,B,B,B,B,B,B,B,B,B,B,B,B, },
    },
  },
};
