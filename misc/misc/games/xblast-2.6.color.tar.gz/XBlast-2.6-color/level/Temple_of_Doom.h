/* XBlast 2.5.3 level */
static BMLevelData Temple_of_Doom =
{
  /* BMLevel */
  {
    "Temple of Doom",
    "The Adelaide Group",
    "xblast.useTempleOfDoom",
    "Who cares for a tip, just play the damn level.",
    GM_Random | GM_4_Player | GM_All,
    (void *) &Temple_of_Doom,
    NULL,
  },
  /* BMShrinkData */
  {
    shrink_spiral,
    SCRAMBLE_VOID,
    SCRAMBLE_VOID,
  },
  /* BMFuncData */
  {
    special_init_void,
    special_game_void,
    special_extra_poison,
    special_key_void,
  },
  /* BMPlayerData */
  {
    0, 0,
    {
      {  1,  1 },
      {  1, 13 },
      { 11, 13 },
      { 11,  1 },
    },
    PM_Inner, 2,
    Healthy, Healthy, IF_None,
  },
  /* BMBombData */
  {
    bomb_click_none, bomb_click_none, bomb_click_none,
    GoStop, FUSEnormal,
    BMTnormal, BMTnormal, BMTnormal,
  },
  /* BMGraphicsData */
  {
    {
      { "karo_light",   "Black", "Gray50", "MidnightBlue" },
      { "karo_light_S", "Black", "Gray50", "MidnightBlue" },
      { "temple",      "Black", "Black", "Gray50" },
      { "temple",      "Black", "Black", "Gray50" },
      { "extra",       "Black", "Gray50", "Red" },
      { "extra_O",     "Black", "Gray50", "Red" },
      EXTRA_BOMB,
      EXTRA_RANGE,
      EXTRA_TRAP,
      EXTRA_POISON,
      { "score_floor",  "Black", "White", "Gray50" },
    },
  },
  /* BMMapData */
  {
    ShadowFull, DEdouble,
    { 16, 48, 48, 60, 60 },
    {
      { B,B,B,B,B,B,B,B,B,B,B,B,B },
      { B,_,_,_,_,_,r,_,_,_,_,_,B },
      { B,_,B,B,B,B,b,B,B,B,B,_,B },
      { B,_,B,_,X,_,X,_,X,_,B,_,B },
      { B,_,B,X,B,X,B,X,B,X,B,_,B },
      { B,_,B,_,X,_,X,_,X,_,B,_,B },
      { B,_,B,X,B,X,B,X,B,X,B,_,B },
      { B,_,B,_,X,_,X,_,X,_,B,_,B },
      { B,_,B,X,B,X,B,X,B,X,B,_,B },
      { B,_,B,_,X,_,X,_,X,_,B,_,B },
      { B,_,B,X,B,X,B,X,B,X,B,_,B },
      { B,_,B,_,X,_,X,_,X,_,B,_,B },
      { B,_,B,B,B,B,r,B,B,B,B,_,B },
      { B,_,_,_,_,_,b,_,_,_,_,_,B },
      { B,B,B,B,B,B,B,B,B,B,B,B,B }
    },
  },
};
