/* XBlast 2.5.3 level */
static BMLevelData Stormy =
{
  /* BMLevel */
  {
    "Stormy",
    "Reem",
    "xblast.useStormy",
    "Blow your way through",
    GM_Random | GM_23456_Player | GM_All,
    (void *) &Stormy,
    NULL,
  },
  /* BMShrinkData */
  {
    shrink_compound,
    SCRAMBLE_VOID,
    SCRAMBLE_VOID,
  },
  /* BMFuncData */
  {
    special_init_void,
    special_game_void,
    special_extra_air,
    special_key_air,
  },
  /* BMPlayerData */
  {
    1, 2,
    {
      {  1,  1 },
      { 11,  1 },
      {  1, 13 },
      { 11, 13 },
      {  1,  7 },
      { 11,  7 },
    },
    PM_Inner, -2,
    Healthy, Healthy, IF_None,
  },
  /* BMBombData */
  {
    bomb_click_snooker, bomb_click_contact, bomb_click_rebound,
    GoStop, FUSEnormal,
    BMTnormal, BMTnormal, BMTnormal,
  },
  /* BMGraphicsData */
  {
    {
      { "iron_floor", "Black", "Magenta", "OrangeRed" },
      { "iron_floor_S", "Black", "Magenta", "OrangeRed" },
      { "dark_block", "Black", "Magenta", "LightSkyBlue" },
      { "dark_block_R", "Black", "Yellow", "Red" },
      { "extra", "Black", "SaddleBrown", "Black" },
      { "extra_O", "Black", "SaddleBrown", "Black" },
      EXTRA_BOMB,
      EXTRA_RANGE,
      EXTRA_TRAP,
      EXTRA_AIRPUMP,
      { "score_floor", "RoyalBlue", "RoyalBlue", "RoyalBlue" },
    },
  },
  /* BMMapData */
  {
    ShadowBlock, DEall,
    { 30, 50, 60, 60, 63 },
    {
      { B,B,B,B,B,B,B,B,B,B,B,B,B, },
      { B,_,_,X,R,_,R,_,R,X,_,_,B, },
      { B,_,R,_,s,_,R,_,s,_,R,_,B, },
      { B,X,_,R,X,R,_,R,X,R,_,X,B, },
      { B,R,s,X,_,R,q,R,_,X,s,R,B, },
      { B,X,R,R,s,_,s,_,s,R,R,X,B, },
      { B,_,R,s,X,R,_,R,X,s,R,_,B, },
      { B,_,_,X,X,_,X,_,X,X,_,_,B, },
      { B,_,R,s,X,R,_,R,X,s,R,_,B, },
      { B,X,R,R,s,_,s,_,s,R,R,X,B, },
      { B,R,s,X,_,R,q,R,_,X,s,R,B, },
      { B,X,_,R,X,R,_,R,X,R,_,X,B, },
      { B,_,R,_,s,_,R,_,s,_,R,_,B, },
      { B,_,_,X,R,_,R,_,R,X,_,_,B, },
      { B,B,B,B,B,B,B,B,B,B,B,B,B, },
    },
  },
};
