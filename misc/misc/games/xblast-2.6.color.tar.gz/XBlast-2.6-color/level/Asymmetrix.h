/* XBlast 2.5.3 level */
static BMLevelData Asymmetrix =
{
  /* BMLevel */
  {
    "Asymmetrix",
    "M. \"Snoopy\" Fries",
    "xblast.useAsymmetrix",
    "???",
    GM_Random | GM_234_Player | GM_Single | GM_Team | GM_LR_Players,
    (void *) &Asymmetrix,
    NULL,
  },
  /* BMShrinkData */
  {
    shrink_compound,
    SCRAMBLE_VOID,
    SCRAMBLE_VOID,
  },
  /* BMFuncData */
  {
    special_init_void,
    special_game_void,
    special_extra_kick,
    special_key_void,
  },
  /* BMPlayerData */
  {
    8, 2,
    {
      {  1,  1 },
      {  1, 13 },
      { 11, 13 },
      { 11,  1 },
    },
    PM_Same, 0,
    IllRun, IllRun, IF_None,
  },
  /* BMBombData */
  {
    bomb_click_none, bomb_click_none, bomb_click_none,
    GoStop, FUSEnormal,
    BMTnormal, BMTnormal, BMTnormal,
  },
  /* BMGraphicsData */
  {
    {
      { "iron_floor",   "Black", "Plum", "SeaGreen" },
      { "iron_floor_S", "Black", "Plum", "SeaGreen" },
      { "dark_block_R", "Black", "ForestGreen", "LimeGreen" },
      { "dark_block",   "Black", "DeepSkyBlue", "LightSkyBlue" },
      { "extra", "Black", "White", "Gray50" },
      { "extra_O", "Black", "White", "Gray50" },
      EXTRA_BOMB,
      EXTRA_RANGE,
      EXTRA_TRAP,
      EXTRA_INVINC,
      { "score_floor", "Maroon", "Red", "Gray50" },
    },
  },
  /* BMMapData */
  {
    ShadowFull, DEall,
    { 0, 0, 0, 0, 0 },
    {
      { B,B,B,B,B,B,B,B,B,B,B,B,B},
      { B,_,R,_,R,_,R,_,_,_,_,_,B},
      { B,_,_,_,_,_,_,_,_,R,_,R,B},
      { B,_,R,_,R,_,R,R,_,_,_,_,B},
      { B,R,_,_,R,_,_,_,R,R,_,_,B},
      { B,_,_,R,_,_,R,_,_,_,_,R,B},
      { B,_,_,_,_,R,_,_,R,R,_,_,B},
      { B,R,_,_,R,R,_,_,_,_,_,R,B},
      { B,_,R,_,_,_,_,R,_,R,_,_,B},
      { B,_,_,_,R,_,R,_,_,_,R,_,B},
      { B,_,_,R,_,_,_,_,R,_,R,_,B},
      { B,R,_,R,_,R,_,R,_,_,_,R,B},
      { B,_,_,_,_,R,_,_,_,R,_,_,B},
      { B,_,_,R,_,_,_,R,_,R,_,_,B},
      { B,B,B,B,B,B,B,B,B,B,B,B,B},
    },
  },
};
