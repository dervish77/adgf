/* XBlast 2.5.3 level */
static BMLevelData Moonwalking =
{
  /* BMLevel */
  {
    "Moonwalking",
    "Keith Gillow",
    "xblast.useMoonwalking",
    "Keep cool and get to the center",
    GM_Random | GM_234_Player | GM_All, 
    (void *) &Moonwalking, 
    NULL,
  },
  /* BMShrinkData */
  {
    shrink_compound,
    SCRAMBLE_VOID,
    SCRAMBLE_VOID,
  },
  /* BMFuncData */
  {
    special_init_void,
    special_game_void,
    special_extra_air,
    special_key_air,
  },
  /* BMPlayerData */
  {
    2, 2,
    {
      { 1, 1 },
      { 1, 13 },
      { 11, 13 },
      { 11, 1 },
    },
    PM_Polar, 2,
    IllReverse, IllReverse, IF_None, 
  },
  /* BMBombData */
  {
    bomb_click_none, bomb_click_none, bomb_click_none,
    GoStop, FUSEnormal,
    BMTnormal, BMTnormal, BMTnormal,
  },
  /* BMGraphicsData */
  {
    {
      { "button_floor",   "Black", "Gray75",    "Black" },
      { "button_floor_S", "Black", "Gray75",    "Black" },
      { "dark_block",     "Black", "Yellow", "DarkTurquoise" },
      { "dark_block_R", "Black", "Yellow", "DarkTurquoise" },
      { "box",           "Black", "Yellow", "Red" },
      { "box",           "Black", "HotPink", "Red" },
      EXTRA_BOMB,
      EXTRA_RANGE,
      EXTRA_TRAP,
      EXTRA_AIRPUMP,
      { "score_floor",    "Red",   "Red",       "RoyalBlue" },
    },
  },
  /* BMMapData */
  {
    ShadowFull, DEall,
    {18,46,48,53,54},
    {
      { B,B,B,B,B,B,B,B,B,B,B,B,B },
      { B,_,_,_,X,_,X,_,X,_,_,_,B },
      { B,_,B,X,B,X,B,X,B,X,B,_,B },
      { B,_,X,_,X,_,X,_,X,_,X,_,B },
      { B,X,B,X,B,X,B,X,B,X,B,X,B },
      { B,_,X,_,X,_,X,_,X,_,X,_,B },
      { B,X,B,X,B,X,B,X,B,X,B,X,B },
      { B,_,X,_,X,_,X,_,X,_,X,_,B },
      { B,X,B,X,B,X,B,X,B,X,B,X,B },
      { B,_,X,_,X,_,X,_,X,_,X,_,B },
      { B,X,B,X,B,X,B,X,B,X,B,X,B },
      { B,_,X,_,X,_,X,_,X,_,X,_,B },
      { B,_,B,X,B,X,B,X,B,X,B,_,B },
      { B,_,_,_,X,_,X,_,X,_,_,_,B },
      { B,B,B,B,B,B,B,B,B,B,B,B,B }
    },
  },
};
