/* XBlast 2.5.3 level */
/* File: level/Chaos.h */
/* Author: Stephan Natschlaeger */
/* Version: 8.1.1998 */
static BMLevelData Chaos =
{
  /* BMLevel */
  {
    "Chaos",
    "Stn",
    "xblast.useChaos",
    "No Rules",
    GM_Random | GM_23456_Player | GM_All,
    (void *) &Chaos,
    NULL,
  },
  /* BMShrinkData */
  {
    shrink_compound,
    SCRAMBLE_VOID,
    SCRAMBLE_VOID,
  },
  /* BMFuncData */
  {
    special_init_void,
    special_game_void,
    special_extra_void,
    special_key_air,
  },
  /* BMPlayerData */
  {
    1, 2,
    {
      {  3,  2 },
      {  9,  2 },
      {  2, 11 },
      {  5,  6 },
      {  8,  8 },
      { 10, 13 },
    },
    PM_Same, 0,
    Healthy, Healthy, IF_Airpump,
  },
  /* BMBombData */
  {
    bomb_click_none, bomb_click_none, bomb_click_contact,
    GoStop, FUSElong,
    BMTnormal, BMTnormal, BMTfirecracker,
  },
  /* BMGraphicsData */
  {
    {
      { "karo_light",   "Black", "SlateBlue", "Green" },
      { "karo_light_S", "Black", "SlateBlue", "Green" },
      { "pyramid",     "Black", "Goldenrod", "SteelBlue" },
      { "pyramid_R", "Black", "Goldenrod", "OrangeRed" },
      { "extra",       "Black", "Sienna",    "Orange" },
      { "extra_O",     "Black", "Sienna",    "Orange" },
      EXTRA_BOMB,
      EXTRA_RANGE,
      EXTRA_TRAP,
      EXTRA_KICK,
      { "score_floor", "RoyalBlue", "RoyalBlue", "RoyalBlue" },
    },
  },
  /* BMMapData */
  {
    ShadowExtra, DEall,
    { 5, 40, 40, 40, 48 },
    {
      { B,B,B,B,B,B,B,B,B,B,B,B,B, },
      { B,_,_,X,_,B,_,_,X,_,_,X,B, },
      { B,B,X,_,s,X,_,_,s,_,B,_,B, },
      { B,_,_,B,_,_,X,X,_,s,_,X,B, },
      { B,X,_,_,X,_,s,_,_,X,s,_,B, },
      { B,_,_,X,_,X,B,_,X,_,_,X,B, },
      { B,X,B,s,X,_,_,X,_,_,B,_,B, },
      { B,_,_,_,_,X,_,X,_,X,_,_,B, },
      { B,s,X,_,X,s,_,_,B,_,_,X,B, },
      { B,_,_,B,_,_,s,X,_,_,B,_,B, },
      { B,_,_,_,s,X,_,_,s,X,_,B,B, },
      { B,B,_,X,_,_,X,B,_,_,s,_,B, },
      { B,_,s,_,B,_,X,_,X,_,X,_,B, },
      { B,_,X,_,_,_,s,_,_,B,_,_,B, },
      { B,B,B,B,B,B,B,B,B,B,B,B,B, },
    },
  },
};
