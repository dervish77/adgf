/* XBlast 2.5.3 level */
static BMLevelData Trench_Warfare =
{
  /* BMLevel */
  {
    "Trench Warfare",
    "The Adelaide Group",
    "xblast.useTrenchWarfare",
    "Don't think you're having all the fun.",
    GM_Random | GM_23456_Player | GM_All,
    (void *) &Trench_Warfare,
    NULL,
  },
  /* BMShrinkData */
  {
    shrink_spiral,
    SCRAMBLE_VOID,
    SCRAMBLE_VOID,
  },
  /* BMFuncData */
  {
    special_init_void,
    special_game_void,
    special_extra_kick,
    special_key_void,
  },
  /* BMPlayerData */
  {
    8, 10,
    {
      {  2,  1 },
      {  2, 13 },
      { 10, 13 },
      { 10,  1 },
      {  3,  7 },
      {  9,  7 },
    },
    PM_Polar, 2,
    Healthy, Healthy, IF_Kick,
  },
  /* BMBombData */
  {
    bomb_click_none, bomb_click_none, bomb_click_none,
    GoStop, FUSEnormal,
    BMTnormal, BMTnormal, BMTnormal,
  },
  /* BMGraphicsData */
  {
    {
      { "chess_floor",    "Black", "LightSteelBlue", "Gray50" },
      { "chess_floor_S",  "Black", "LightSteelBlue", "Gray50" },
      { "book_shelf",     "Black", "DarkGreen", "SteelBlue" },
      { "book_shelf",     "Black", "Firebrick", "SteelBlue" },
      { "chess_sphere",   "Black", "tan", "OliveDrab" },
      { "chess_sphere_O", "Black", "tan", "OliveDrab" },
      EXTRA_BOMB,
      EXTRA_RANGE,
      EXTRA_TRAP,
      EXTRA_KICK,
      { "check",         "Black", "White", "Gray50" },
    },
  },
  /* BMMapData */
  {
    ShadowBlock, DEall,
    { 0, 0, 0, 0, 0 },
    {
      { B,B,B,B,B,B,B,B,B,B,B,B,B },
      { B,B,_,_,_,_,_,_,_,_,_,B,B },
      { B,B,_,_,_,_,_,_,_,_,_,B,B },
      { B,B,_,R,R,R,_,R,R,R,_,B,B },
      { B,B,_,R,_,B,_,B,_,R,_,B,B },
      { B,B,_,R,B,_,_,_,B,R,_,B,B },
      { B,B,_,R,_,B,_,B,_,R,_,B,B },
      { B,B,_,_,_,_,_,_,_,_,_,B,B },
      { B,B,_,R,_,B,_,B,_,R,_,B,B },
      { B,B,_,R,B,_,_,_,B,R,_,B,B },
      { B,B,_,R,_,B,_,B,_,R,_,B,B },
      { B,B,_,R,R,R,_,R,R,R,_,B,B },
      { B,B,_,_,_,_,_,_,_,_,_,B,B },
      { B,B,_,_,_,_,_,_,_,_,_,B,B },
      { B,B,B,B,B,B,B,B,B,B,B,B,B }
    },
  },
};


