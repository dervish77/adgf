/* XBlast 2.5.3 level */
static BMLevelData The_Fundamental_Error =
{
  /* BMLevel */
  {
    "The Fundamental Error",
    "The Adelaide Group (mwblack)",
    "xblast.useTheFundamentalError",
    "Winning the start is all important.",
    GM_Random | GM_23456_Player | GM_All,
    (void *) &The_Fundamental_Error,
    NULL,
  },
  /* BMShrinkData */
  {
    shrink_compound,
    SCRAMBLE_VOID,
    SCRAMBLE_VOID,
  },
  /* BMFuncData */
  {
    special_init_void,
    special_game_void,
    special_extra_void,
    special_key_void,
  },
  /* BMPlayerData */
  {
    1, 2,
    {
      {  6,  7 },
      {  6,  7 },
      {  6,  7 },
      {  6,  7 },
      {  6,  7 },
      {  6,  7 },
    },
    PM_Same, 0,
    Healthy, Healthy, IF_None,
  },
  /* BMBombData */
  {
    bomb_click_none, bomb_click_none, bomb_click_none,
    GoStop, FUSEnormal,
    BMTnormal, BMTnormal, BMTnormal,
  },
  /* BMGraphicsData */
  {
    {
      { "button_floor",   "Black", "LightSteelBlue", "Gray50" },
      { "button_floor_S", "Black", "LightSteelBlue", "Gray50" },
      { "dark_block",     "Black", "SteelBlue", "SlateBlue" },
      { "dark_block_R",   "Black", "SkyBlue", "RoyalBlue" },
      { "box",            "Black", "SeaGreen",    "SpringGreen" },
      { "box",            "Black", "MediumSeaGreen", "Aquamarine" },
      EXTRA_BOMB,
      EXTRA_RANGE,
      EXTRA_TRAP,
      EXTRA_KICK,
      { "score_floor", "Black", "White", "Gray50" },
    },
  },
  /* BMMapData */
  {
    ShadowFull, DEall,
    { 16, 48, 48, 48, 48 },
    {
      { B,B,B,B,B,B,B,B,B,B,B,B,B },
      { B,r,b,r,B,_,_,_,r,X,X,r,B },
      { B,r,b,r,B,_,B,_,B,X,r,X,B },
      { B,r,r,r,B,_,B,_,B,r,B,X,B },
      { B,r,b,r,B,_,B,_,X,b,b,b,B },
      { B,r,b,r,_,_,X,_,X,B,B,b,B },
      { B,s,_,_,B,X,B,_,_,_,B,b,B },
      { B,s,b,s,s,X,_,b,X,_,b,b,B },
      { B,s,_,_,B,X,B,_,_,_,B,b,B },
      { B,b,b,b,_,_,X,_,X,B,B,b,B },
      { B,r,b,r,B,_,B,_,X,b,b,b,B },
      { B,r,b,r,B,_,B,_,B,r,B,X,B },
      { B,r,b,r,B,_,B,_,B,X,r,X,B },
      { B,b,b,b,B,_,_,_,r,X,X,r,B },
      { B,B,B,B,B,B,B,B,B,B,B,B,B }
    },
  },
};
