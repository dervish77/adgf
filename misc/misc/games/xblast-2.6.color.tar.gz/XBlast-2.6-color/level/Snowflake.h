/* XBlast 2.5.3 level */
/* File: level/Snowflake.h */
/* Author: Stephan Natschlaeger */
/* Version: 16.12.1997 */
static BMLevelData Snowflake =
{
  /* BMLevel */
  {
    "Snowflake",
    "Stn",
    "xblast.useSnowflake",
    "",
    GM_Random | GM_234_Player | GM_All,
    (void *) &Snowflake,
    NULL,
  },
  /* BMShrinkData */
  {
    shrink_void,
    SCRAMBLE_VOID,
    SCRAMBLE_VOID,
  },
  /* BMFuncData */
  {
    special_init_void,
    special_game_void,
    special_extra_void,
    special_key_RC,
  },
  /* BMPlayerData */
  {
    3, 5,
    {
      {  1,  1 },
      {  1, 13 },
      {  1,  4 },
      {  1, 10 },
    },
    PM_Same, 0,
    Healthy, Healthy, IF_RC,
  },
  /* BMBombData */
  {
    bomb_click_none, bomb_click_none, bomb_click_none,
    GoDown, FUSEnormal,
    BMTnormal, BMTnormal, BMTnormal,
  },
  /* BMGraphicsData */
  {
    {
      { "iron_floor",      "Black", "Lavender", "Turquoise" },
      { "iron_floor_S",    "Black", "Lavender", "Turquoise" },
      { "dark_block",      "Black", "SeaGreen", "MediumSeaGreen" },
      { "dark_block_R",  "Black",   "SeaGreen", "MediumSeaGreen" },
      { "extra",          "Black", "SteelBlue", "DeepSkyBlue" },
      { "extra_O",        "Black", "SteelBlue", "DeepSkyBlue" },
      EXTRA_BOMB,
      EXTRA_RANGE,
      EXTRA_TRAP,
      EXTRA_KICK,
      { "score_floor", "RoyalBlue", "RoyalBlue", "RoyalBlue" },
    },
  },
  /* BMMapData */
  {
    ShadowExtra, DEall,
    { 20, 25, 40, 40, 40 },
    {
      { B,B,B,B,B,B,B,B,B,B,B,B,B, },
      { B,_,_,X,_,X,_,X,_,X,_,_,B, },
      { B,_,B,_,_,X,B,X,_,_,B,_,B, },
      { B,X,_,B,X,_,B,_,X,B,_,X,B, },
      { B,_,_,_,B,X,B,X,B,_,_,_,B, },
      { B,_,_,_,X,_,_,_,X,_,_,_,B, },
      { B,X,_,B,_,X,_,X,_,B,_,X,B, },
      { B,_,B,B,B,_,B,_,B,B,B,_,B, },
      { B,X,_,B,_,X,_,X,_,B,_,X,B, },
      { B,_,_,_,X,_,_,_,X,_,_,_,B, },
      { B,_,_,_,B,X,B,X,B,_,_,_,B, },
      { B,X,_,B,X,_,B,_,X,B,_,X,B, },
      { B,_,B,_,_,X,B,X,_,_,B,_,B, },
      { B,_,_,X,_,X,_,X,_,X,_,_,B, },
      { B,B,B,B,B,B,B,B,B,B,B,B,B, },
    },
  },
};
