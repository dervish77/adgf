/* XBlast 2.5.3 level */
static BMLevelData Try_It_And_See =
{
  /* BMLevel */
  {
    "Try It and See",
    "The Adelaide Group",
    "xblast.useTryItAndSee",
    "Multiple pickups - they're a bit of a gamble.",
    GM_Random | GM_234_Player | GM_All,
    (void *) &Try_It_And_See,
    NULL,
  },
  /* BMShrinkData */
  {
    shrink_spiral,
    SCRAMBLE_VOID,
    SCRAMBLE_VOID,
  },
  /* BMFuncData */
  {
    special_init_void,
    special_game_void,
    special_extra_multiple,
    special_key_air,
  },
  /* BMPlayerData */
  {
    3, 4,
    {
      {  1,  1 },
      {  1, 13 },
      { 11, 13 },
      { 11,  1 },
    },
    PM_Inner, 2,
    Healthy, Healthy, IF_Kick,
  },
  /* BMBombData */
  {
    bomb_click_none, bomb_click_none, bomb_click_none,
    GoStop, FUSEnormal,
    BMTnormal, BMTnormal, BMTnormal,
  },
  /* BMGraphicsData */
  {
    {
      { "karo_light",   "Black", "LightSkyBlue", "RoyalBlue" },
      { "karo_light_S", "Black", "LightSkyBlue", "RoyalBlue" },
      { "pyramid",     "Black", "SlateBlue", "White" },
      { "pyramid_R", "Black", "SlateBlue", "White" },
      { "extra",       "Black", "OrangeRed", "Gold" },
      { "extra_O",     "Black", "OrangeRed", "Gold" },
      EXTRA_BOMB,
      EXTRA_RANGE,
      EXTRA_TRAP,
      EXTRA_MULTIPLE,
      { "score_floor", "Black", "Gray50", "White" },
    },
  },
  /* BMMapData */
  {
    ShadowFull, DEall,
    { 8, 16, 16, 35, 63 },
    {
      { B,B,B,B,B,B,B,B,B,B,B,B,B },
      { B,_,_,_,X,q,B,q,X,_,_,_,B },
      { B,B,B,_,_,X,B,X,_,_,B,B,B },
      { B,q,B,_,X,_,X,_,X,_,B,q,B },
      { B,X,_,X,B,X,B,X,B,X,_,X,B },
      { B,q,X,_,X,q,X,q,X,_,X,q,B },
      { B,X,_,X,B,X,B,X,B,X,_,X,B },
      { B,q,X,_,X,q,X,q,X,_,X,q,B },
      { B,X,_,X,B,X,B,X,B,X,_,X,B },
      { B,q,X,_,X,q,X,q,X,_,X,q,B },
      { B,X,_,X,B,X,B,X,B,X,_,X,B },
      { B,q,B,_,X,_,X,_,X,_,B,q,B },
      { B,B,B,_,_,X,B,X,_,_,B,B,B },
      { B,_,_,_,X,q,B,q,X,_,_,_,B },
      { B,B,B,B,B,B,B,B,B,B,B,B,B }
    },
  },
};
