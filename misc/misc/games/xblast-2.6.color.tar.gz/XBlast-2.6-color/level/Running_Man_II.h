/* XBlast 2.5.3 level */
static BMLevelData Running_Man_II =
{
  /* BMLevel */
  {
    "Running Man II",
    "The Adelaide Group",
    "xblast.useRunningManII",
    "Use the cloak wisely, don't waste it.",
    GM_Random | GM_234_Player | GM_SinglePlayer,
    (void *) &Running_Man_II,
    NULL,
  },
  /* BMShrinkData */
  {
    shrink_void,
    SCRAMBLE_VOID,
    SCRAMBLE_VOID,
  },
  /* BMFuncData */
  {
    special_init_void,
    special_game_void,
    special_extra_cloak,
    special_key_cloak,
  },
  /* BMPlayerData */
  {
    1, 2,
    {
      {  1,  1 },
      {  1, 13 },
      { 11, 13 },
      { 11,  1 },
    },
    PM_Polar, 2,
    IllRun, IllRun, IF_None,
  },
  /* BMBombData */
  {
    bomb_click_none, bomb_click_none, bomb_click_none,
    GoStop, FUSEnormal,
    BMTnormal, BMTnormal, BMTnormal,
  },
  /* BMGraphicsData */
  {
    {
      { "chess_floor",    "Black", "PapayaWhip", "Gray50" },
      { "chess_floor_S",  "Black", "PapayaWhip", "Gray50" },
      { "book_shelf",     "Black", "Aquamarine", "CornflowerBlue" },
      { "book_shelf",     "Black", "Maroon",     "CornflowerBlue" },
      { "chess_sphere",   "Black", "PapayaWhip", "OrangeRed" },
      { "chess_sphere_O", "Black", "PapayaWhip", "OrangeRed" },
      EXTRA_BOMB,
      EXTRA_RANGE,
      EXTRA_TRAP,
      EXTRA_CLOAK,
      { "check",        "Black", "White", "Gray50" },
    },
  },
  /* BMMapData */
  {
    ShadowBlock, DEall,
    { 20, 36, 36, 48, 48 },
    {
      { B,B,B,B,B,B,B,B,B,B,B,B,B },
      { B,_,_,_,X,_,X,_,X,_,_,_,B },
      { B,_,R,X,R,X,R,X,R,X,R,_,B },
      { B,_,X,_,_,_,X,_,_,_,X,_,B },
      { B,_,R,_,R,X,R,X,R,_,R,_,B },
      { B,_,X,_,X,_,X,_,X,_,X,_,B },
      { B,X,R,X,R,_,R,_,R,X,R,X,B },
      { B,_,X,_,X,_,X,_,X,_,X,_,B },
      { B,X,R,X,R,_,R,_,R,X,R,X,B },
      { B,_,X,_,X,_,X,_,X,_,X,_,B },
      { B,_,R,_,R,X,R,X,R,_,R,_,B },
      { B,_,X,_,_,_,X,_,_,_,X,_,B },
      { B,_,R,X,R,X,R,X,R,X,R,_,B },
      { B,_,_,_,X,_,X,_,X,_,_,_,B },
      { B,B,B,B,B,B,B,B,B,B,B,B,B }
    },
  },
};


