/* XBlast 2.5.3 level */
static BMLevelData Full_Power_Level_II =
{
  /* BMLevel */
  {
    "Full Power Level II",
    "The Adelaide Group",
    "xblast.useFullPowerLevelII",
    "Retain your kickers at all costs.",
    GM_Random | GM_23456_Player | GM_All,
    (void *) &Full_Power_Level_II,
    NULL,
  },
  /* BMShrinkData */
  {
    shrink_spiral,
    SCRAMBLE_VOID,
    SCRAMBLE_VOID,
  },
  /* BMFuncData */
  {
    special_init_void,
    special_game_void,
    special_extra_kick,
    special_key_void,
  },
  /* BMPlayerData */
  {
    3, 3,
    {
      {  1,  1 },
      {  1, 13 },
      { 11, 13 },
      { 11,  1 },
      {  1,  7 },
      { 11,  7 },
    },
    PM_Polar, 1,
    Healthy, Healthy, IF_None,
  },
  /* BMBombData */
  {
    bomb_click_none, bomb_click_none, bomb_click_none,
    GoStop, FUSEnormal,
    BMTnormal, BMTnormal, BMTnormal,
  },
  /* BMGraphicsData */
  {
    {
      { "karo_light",   "Black", "LightBlue", "Plum" },
      { "karo_light_S", "Black", "LightBlue", "Plum" },
      { "box",         "Black", "BlueViolet", "SpringGreen" },
      { "box",         "Black", "DodgerBlue", "Aquamarine" },
      { "extra",       "Black", "Gold", "Orchid" },
      { "extra_O",     "Black", "Gold", "Orchid" },
      EXTRA_BOMB,
      EXTRA_RANGE,
      EXTRA_TRAP,
      EXTRA_KICK,
      { "score_floor",  "Red", "Red", "Gray50" },
    },
  },
  /* BMMapData */
  {
    ShadowFull, DEall,
    { 16, 48, 48, 60, 60 },
    {
      { B,B,B,B,B,B,B,B,B,B,B,B,B },
      { B,_,_,_,_,_,_,_,_,_,_,_,B },
      { B,_,X,_,X,_,X,_,X,_,X,_,B },
      { B,_,_,X,_,X,_,X,_,X,_,_,B },
      { B,_,X,_,X,_,X,_,X,_,X,_,B },
      { B,_,_,X,_,X,_,X,_,X,_,_,B },
      { B,_,X,_,X,_,X,_,X,_,X,_,B },
      { B,_,_,X,B,X,_,X,B,X,_,_,B },
      { B,_,X,_,X,_,X,_,X,_,X,_,B },
      { B,_,_,X,_,X,_,X,_,X,_,_,B },
      { B,_,X,_,X,_,X,_,X,_,X,_,B },
      { B,_,_,X,_,X,_,X,_,X,_,_,B },
      { B,_,X,_,X,_,X,_,X,_,X,_,B },
      { B,_,_,_,_,_,_,_,_,_,_,_,B },
      { B,B,B,B,B,B,B,B,B,B,B,B,B }
    },
  },
};
