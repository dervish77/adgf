/* XBlast 2.5.3 level */
static BMLevelData Eraser =
{
  /* BMLevel */
  {
    "Eraser",
    "Markus Schreiber",
    "xblast.useEraser",
    "Don't get erased",
    GM_Random | GM_23456_Player | GM_All,
    (void *) &Eraser,
    NULL,
  },
  /* BMShrinkData */
  {
    shrink_void,
    SCRAMBLE_VOID,
    SCRAMBLE_VOID,
  },
  /* BMFuncData */
  {
    special_init_void,
    special_game_void,
    special_extra_special_bomb,
    special_key_special_bomb,
  },
  /* BMPlayerData */
  {
    1, 2,
    {
      {  3,  3 },
      {  3, 11 },
      {  9, 11 },
      {  9,  3 },
      {  3,  7 },
      {  9,  7 },
    },
    PM_Same, 2,
    Healthy, Healthy, IF_Kick,
  },
  /* BMBombData */
  {
    bomb_click_none, bomb_click_none, bomb_click_none,
    GoStop, FUSEnormal,
    BMTnormal, BMTtrianglebombs, BMTnormal,
  },
  /* BMGraphicsData */
  {
    {
      { "city_free", "Black", "Coral", "SteelBlue" },
      { "city_free_S", "Black", "Coral", "SteelBlue" },
      { "city_rip", "Black", "SteelBlue", "Coral" },
      { "city_rip_R", "Black", "LightSteelBlue", "Coral" },
      { "light_house", "Black", "SteelBlue", "Black" },
      { "light_house_O", "Black", "SteelBlue", "Black" },
      EXTRA_BOMB,
      EXTRA_RANGE,
      EXTRA_TRAP,
      EXTRA_TRIANGLE,
      { "score_floor", "RoyalBlue", "RoyalBlue", "RoyalBlue" },
    },
  },
  /* BMMapData */
  {
    ShadowFull, DEspecial,
    { 18, 38, 48, 62, 64 },
    {
      { B,B,B,B,B,B,B,B,B,B,B,B,B, },
      { B,X,_,_,X,_,X,_,X,_,_,X,B, },
      { B,_,X,_,B,X,X,X,B,_,X,_,B, },
      { B,_,X,_,X,_,X,_,X,_,X,_,B, },
      { B,X,B,X,B,B,X,B,B,X,B,X,B, },
      { B,_,X,_,B,_,X,_,B,_,X,_,B, },
      { B,_,B,_,X,_,X,_,X,_,B,_,B, },
      { B,X,_,_,X,X,X,X,X,_,_,X,B, },
      { B,_,B,_,X,_,X,_,X,_,B,_,B, },
      { B,_,X,_,B,_,X,_,B,_,X,_,B, },
      { B,X,B,X,B,B,X,B,B,X,B,X,B, },
      { B,_,X,_,X,_,X,_,X,_,X,_,B, },
      { B,_,X,_,B,X,X,X,B,_,X,_,B, },
      { B,X,_,_,X,_,X,_,X,_,_,X,B, },
      { B,B,B,B,B,B,B,B,B,B,B,B,B, },
    },
  },
};
