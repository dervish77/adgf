/* XBlast 2.5.3 level */
static BMLevelData Mayhem =
{
  /* BMLevel */
  {
    "Mayhem",
    "The Adelaide Group",
    "xblast.useMayhem",
    "Use the mayhem to waste those who don't have it.",
    GM_Random | GM_23456_Player | GM_All,
    (void *) &Mayhem,
    NULL,
  },
  /* BMShrinkData */
  {
    shrink_speed_spiral,
    SCRAMBLE_VOID,
    SCRAMBLE_VOID,
  },
  /* BMFuncData */
  {
    special_init_void,
    special_game_void,
    special_extra_mayhem,
    special_key_void,
  },
  /* BMPlayerData */
  {
    1, 2,
    {
      {  1,  1 },
      {  1, 13 },
      { 11, 13 },
      { 11,  1 },
      {  3,  7 },
      {  9,  7 },
    },
    PM_Polar, 2,
    Healthy, Healthy, IF_None,
  },
  /* BMBombData */
  {
    bomb_click_none, bomb_click_none, bomb_click_none,
    GoStop, FUSEnormal,
    BMTnormal, BMTnormal, BMTnormal,
  },
  /* BMGraphicsData */
  {
    {
      { "chess_floor",    "Black", "Aquamarine", "Gray50" },
      { "chess_floor_S",  "Black", "Aquamarine", "Gray50" },
      { "book_shelf",     "Black", "Tan", "RoyalBlue" },
      { "book_shelf",     "Black", "Tan", "SeaGreen" },
      { "chess_sphere",   "Black", "Aquamarine", "Red" },
      { "chess_sphere_O", "Black", "Aquamarine", "Red" },
      EXTRA_BOMB,
      EXTRA_RANGE,
      EXTRA_TRAP,
      EXTRA_MAYHEM,
      { "score_floor", "Black", "White", "Gray50" },
    },
  },
  /* BMMapData */
  {
    ShadowBlock, DEall,
    { 20, 36, 36, 48, 48 },
    {
      { B,B,B,B,B,B,B,B,B,B,B,B,B },
      { B,_,_,_,X,_,X,_,X,_,_,_,B },
      { B,_,R,X,R,X,R,X,R,X,R,_,B },
      { B,_,X,X,_,_,X,_,_,X,X,_,B },
      { B,_,R,_,R,X,R,X,R,_,R,_,B },
      { B,_,X,_,X,_,X,_,X,_,X,_,B },
      { B,X,R,_,R,X,R,X,R,_,R,X,B },
      { B,X,_,_,X,_,X,_,X,_,_,X,B },
      { B,X,R,_,R,X,R,X,R,_,R,X,B },
      { B,_,X,_,X,_,X,_,X,_,X,_,B },
      { B,_,R,_,R,X,R,X,R,_,R,_,B },
      { B,_,X,X,_,_,X,_,_,X,X,_,B },
      { B,_,R,X,R,X,R,X,R,X,R,_,B },
      { B,_,_,_,X,_,X,_,X,_,_,_,B },
      { B,B,B,B,B,B,B,B,B,B,B,B,B }
    },
  },
};
