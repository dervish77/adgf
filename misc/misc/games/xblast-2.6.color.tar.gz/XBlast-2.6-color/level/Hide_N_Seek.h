/* XBlast 2.5.3 level */
static BMLevelData Hide_N_Seek =
{
  /* BMLevel */
  {
    "Hide'n Seek",
    "The Adelaide Group",
    "xblast.useHideNSeek",
    "Just hide, don't worry about the seek.",
    GM_Random | GM_23456_Player | GM_SinglePlayer,
    (void *) &Hide_N_Seek,
    NULL,
  },
  /* BMShrinkData */
  {
    shrink_spiral,
    SCRAMBLE_VOID,
    SCRAMBLE_VOID,
  },
  /* BMFuncData */
  {
    special_init_void,
    special_game_void,
    special_extra_cloak,
    special_key_cloak,
  },
  /* BMPlayerData */
  {
    1, 2,
    {
      {  1,  1 },
      {  1, 13 },
      { 11, 13 },
      { 11,  1 },
      {  6,  3 },
      {  6, 11 },
    },
    PM_Polar, 2,
    Healthy, Healthy, IF_Kick,
  },
  /* BMBombData */
  {
    bomb_click_none, bomb_click_none, bomb_click_none,
    GoStop, FUSEnormal,
    BMTnormal, BMTnormal, BMTnormal,
  },
  /* BMGraphicsData */
  {
    {
      { "karo_light",    "Black", "DodgerBlue",  "LightSkyBlue" },
      { "karo_light_S",  "Black", "DodgerBlue",  "LightSkyBlue" },
      { "pyramid",       "Black", "Chocolate",   "White" },
      { "pyramid_R",     "Black", "Chocolate",   "Sienna" },
      { "extra",         "Black", "ForestGreen", "Aquamarine" },
      { "extra_O",       "Black", "ForestGreen", "Aquamarine" },
      EXTRA_BOMB,
      EXTRA_RANGE,
      EXTRA_TRAP,
      EXTRA_CLOAK,
      { "check",        "Black", "White", "Gray50" },
    },
  },
  /* BMMapData */
  {
    ShadowFull, DEall,
    { 16, 48, 48, 60, 60 },
    {
      { B,B,B,B,B,B,B,B,B,B,B,B,B },
      { B,_,_,_,X,_,X,_,X,_,_,_,B },
      { B,_,B,X,B,X,B,X,B,X,B,_,B },
      { B,_,X,X,_,_,_,_,_,X,X,_,B },
      { B,X,B,_,B,X,B,X,B,_,B,X,B },
      { B,_,X,_,X,_,X,_,X,_,X,_,B },
      { B,_,B,X,B,X,_,X,B,X,B,_,B },
      { B,X,X,X,_,_,X,_,_,X,X,X,B },
      { B,_,B,X,B,X,_,X,B,X,B,_,B },
      { B,_,X,_,X,_,X,_,X,_,X,_,B },
      { B,X,B,_,B,X,B,X,B,_,B,X,B },
      { B,_,X,X,_,_,_,_,_,X,X,_,B },
      { B,_,B,X,B,X,B,X,B,X,B,_,B },
      { B,_,_,_,X,_,X,_,X,_,_,_,B },
      { B,B,B,B,B,B,B,B,B,B,B,B,B }
    },
  },
};


