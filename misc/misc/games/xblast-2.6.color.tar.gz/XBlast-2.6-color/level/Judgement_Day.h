/* XBlast 2.5.3 level */
static BMLevelData Judgement_Day =
{
  /* BMLevel */
  {
    "Judgement Day",
    "M. \"Snoopy\" Fries",
    "xblast.useJudgementDay",
    "???",
    GM_Random | GM_23456_Player | GM_All,
    (void *) &Judgement_Day,
    NULL,
  },
  /* BMShrinkData */
  {
    shrink_void,
    SCRAMBLE_VOID,
    SCRAMBLE_VOID,
  },
  /* BMFuncData */
  {
    special_init_void,
    special_game_void,
    special_extra_kick,
    special_key_RC,
  },
  /* BMPlayerData */
  {
    2, 2,
    {
      {  5,  5 },
      {  5,  9 },
      {  7,  9 },
      {  7,  5 },
      {  3,  7 },
      {  9,  7 }
    },
    PM_Polar, -2,
    Healthy, Healthy, IF_Kick | IF_RC,
  },
  /* BMBombData */
  {
    bomb_click_none, bomb_click_none, bomb_click_none,
    GoStop, FUSEnormal,
    BMTnormal, BMTnormal, BMTnormal,
  },
  /* BMGraphicsData */
  {
    {
      { "iron_floor",   "Black", "BlueViolet", "SpringGreen" },
      { "iron_floor_S", "Black", "BlueViolet", "SpringGreen" },
      { "dark_block", "Black", "SpringGreen", "Aquamarine" },
      { "dark_block_R", "Black", "SpringGreen", "Aquamarine" },
      { "extra", "Black", "Gold", "OrangeRed" },
      { "extra_O", "Black", "Gold", "OrangeRed" },
      EXTRA_BOMB,
      EXTRA_RANGE,
      EXTRA_TRAP,
      EXTRA_INVINC,
      { "score_floor", "Black", "White", "Gray50" },
    },
  },
  /* BMMapData */
  {
    ShadowFull, DEall,
    { 0, 0, 0, 0, 60 },
    {
      { B,B,B,B,B,B,B,B,B,B,B,B,B},
      { B,_,_,_,_,B,_,B,_,_,_,_,B},
      { B,_,_,_,B,X,X,X,B,_,_,_,B},
      { B,_,_,B,_,_,_,_,_,B,_,_,B},
      { B,_,B,_,X,_,X,_,X,_,B,_,B},
      { B,B,_,_,_,_,_,_,_,_,_,B,B},
      { B,_,X,_,_,_,_,_,_,_,X,_,B},
      { B,B,X,_,X,_,B,_,X,_,X,B,B},
      { B,_,X,_,_,_,_,_,_,_,X,_,B},
      { B,B,_,_,_,_,_,_,_,_,_,B,B},
      { B,_,B,_,X,_,X,_,X,_,B,_,B},
      { B,_,_,B,_,_,_,_,_,B,_,_,B},
      { B,_,_,_,B,X,X,X,B,_,_,_,B},
      { B,_,_,_,_,B,_,B,_,_,_,_,B},
      { B,B,B,B,B,B,B,B,B,B,B,B,B},
    },
  },
};
