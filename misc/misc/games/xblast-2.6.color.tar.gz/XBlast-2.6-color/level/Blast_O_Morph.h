/* XBlast 2.5.3 level */
static BMLevelData Blast_O_Morph =
{
  /* BMLevel */
  {
    "Blast O Morph",
    "Oliver Vogel",
    "xblast.useBlastOMorph",
    "Be one with the bomb ...",
    GM_Random | GM_23456_Player | GM_All,
    (void *) &Blast_O_Morph,
    NULL,
  },
  /* BMShrinkData */
  {
    shrink_spiral,
    SCRAMBLE_VOID,
    SCRAMBLE_VOID,
  },
  /* BMFuncData */
  {
    special_init_void,
    special_game_void,
    special_extra_morph,
    special_key_morph,
  },
  /* BMPlayerData */
  {
    1, 2,
    {
      {  1,  1 },
      {  1, 13 },
      { 11, 13 },
      { 11,  1 },
      {  1,  7 },
      { 11,  7 },
    },
    PM_Polar, 2,
    Healthy, Healthy, IF_Kick,
  },
  /* BMBombData */
  {
    bomb_click_none, bomb_click_none, bomb_click_none,
    GoStop, FUSEnormal,
    BMTnormal, BMTnormal, BMTnormal,
  },
  /* BMGraphicsData */
  {
    {
      { "ghost", "Black", "LightSlateBlue", "Black" },
      { "ghost", "Black", "LightSlateBlue", "Black" },
      { "ghost_sq", "Black", "LightSlateBlue", "Black" },
      { "ghost_sq_R", "Black", "LightSlateBlue", "Black" },
      { "ghost_ci", "Black", "LightSlateBlue", "Aquamarine" },
      { "ghost_ci_R", "Black", "LightSlateBlue", "Aquamarine" },
      EXTRA_BOMB,
      EXTRA_RANGE,
      EXTRA_TRAP,
      EXTRA_MORPH,
      { "score_floor", "RoyalBlue", "RoyalBlue", "RoyalBlue" },
    },
  },
  /* BMMapData */
  {
    ShadowFull, DEall,
    { 12, 36, 36, 60, 60 },
    {
      { B,B,B,B,B,B,B,B,B,B,B,B,B, },
      { B,_,_,_,X,_,X,_,X,_,_,_,B, },
      { B,_,B,B,B,X,B,X,B,B,B,_,B, },
      { B,_,X,_,X,_,B,_,X,_,X,_,B, },
      { B,X,B,X,B,X,B,X,B,X,B,X,B, },
      { B,_,X,_,B,_,X,_,B,_,X,_,B, },
      { B,_,B,B,B,X,B,X,B,B,B,X,B, },
      { B,_,_,_,X,_,X,_,X,_,_,_,B, },
      { B,X,B,B,B,X,B,X,B,B,B,_,B, },
      { B,_,X,_,B,_,X,_,B,_,X,_,B, },
      { B,X,B,X,B,X,B,X,B,X,B,X,B, },
      { B,_,X,_,X,_,B,_,X,_,X,_,B, },
      { B,_,B,B,B,X,B,X,B,B,B,_,B, },
      { B,_,_,_,X,_,X,_,X,_,_,_,B, },
      { B,B,B,B,B,B,B,B,B,B,B,B,B, },
    },
  },
};
