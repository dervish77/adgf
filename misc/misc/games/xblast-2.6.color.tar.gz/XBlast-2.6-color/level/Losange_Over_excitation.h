/* XBlast 2.5.3 level */
static BMPosition Losange_Scramble[] = {
  {4,6}, {5,5}, {8,6}, {7,5},
  {4,8}, {5,9}, {8,8}, {7,9},
};
static BMLevelData Losange_Over_excitation =
{
  /* BMLevel */
  {
    "Losange Over-excitation",
    "Joachim Kaltz",
    "xblast.useLosangeOverexcitation",
    "Getting kick bombs will help",
    GM_Random | GM_234_Player | GM_Single | GM_Team | GM_LR_Players,
    (void *) &Losange_Over_excitation,
    NULL,
  },
  /* BMShrinkData */
  {
    shrink_spiral_plus,
    SCRAMBLE_VOID,
    { 3*GAME_TIME/4, 8, Losange_Scramble, },
  },
  /* BMFuncData */
  {
    special_init_void,
    special_game_void,
    special_extra_kick,
    special_key_void,
  },
  /* BMPlayerData */
  {
    1, 2,
    {
      {  1,  7 },
      {  6, 12 },
      { 11,  7 },
      {  6,  2 },
      { -1, -1 },
      { -1, -1 },
    },
    PM_Same, 0,
    Healthy, Healthy, IF_None,
  },
  /* BMBombData */
  {
    bomb_click_none, bomb_click_none, bomb_click_none,
    GoStop, FUSEnormal,
    BMTnormal, BMTnormal, BMTnormal,
  },
  /* BMGraphicsData */
  {
    {
      { "hex", "Black", "Tomato", "Red" },
      { "hex", "Black", "Tomato", "Red" },
      { "hex_wall", "Black", "Tomato", "OrangeRed" },
      { "hex_extra", "Black", "Tomato", "Orange" },
      { "hex_extra", "Black", "Tomato", "Yellow" },
      { "hex_extra_O", "Black", "Tomato", "Yellow" },
      EXTRA_BOMB,
      EXTRA_RANGE,
      EXTRA_TRAP,
      EXTRA_KICK,
      { "hex", "Black", "Tomato", "RoyalBlue" },
    },
  },
  /* BMMapData */
  {
    ShadowNone, DEall,
    { 16, 32, 32, 40, 60 },
    {
      { v,v,v,v,v,v,v,v,v,v,v,v,v, },
      { v,v,v,v,B,B,B,B,B,v,v,v,v, },
      { v,v,v,B,B,_,_,_,B,B,v,v,v, },
      { v,v,B,B,X,X,_,X,X,B,B,v,v, },
      { v,B,B,X,X,X,X,X,X,X,B,B,v, },
      { B,B,X,X,X,B,X,B,X,X,X,B,B, },
      { B,_,X,X,B,B,X,B,B,X,X,_,B, },
      { B,_,_,X,X,X,X,X,X,X,_,_,B, },
      { B,_,X,X,B,B,X,B,B,X,X,_,B, },
      { B,B,X,X,X,B,X,B,X,X,X,B,B, },
      { v,B,B,X,X,X,X,X,X,X,B,B,v, },
      { v,v,B,B,X,X,_,X,X,B,B,v,v, },
      { v,v,v,B,B,_,_,_,B,B,v,v,v, },
      { v,v,v,v,B,B,B,B,B,v,v,v,v, },
      { v,v,v,v,v,v,v,v,v,v,v,v,v, },
    },
  },
};
