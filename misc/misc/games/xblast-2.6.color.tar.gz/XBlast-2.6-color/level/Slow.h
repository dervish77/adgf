/* XBlast 2.5.3 level */
static BMLevelData Slow =
{
  /* BMLevel */
  {
    "D'Oh",
    "The Adelaide Group",
    "xblast.useSlow",
    "Survive the slow to gain a possible life advantage.",
    GM_Random | GM_23456_Player | GM_All,
    (void *) &Slow,
    NULL,
  },
  /* BMShrinkData */
  {
    shrink_spiral,
    SCRAMBLE_VOID,
    SCRAMBLE_VOID,
  },
  /* BMFuncData */
  {
    special_init_void,
    special_game_void,
    special_extra_slow,
    special_key_void,
  },
  /* BMPlayerData */
  {
    1, 3,
    {
      {  1,  1 },
      {  1, 13 },
      { 11, 13 },
      { 11,  1 },
      {  1,  7 },
      { 11,  7 },
    },
    PM_Polar, 1,
    Healthy, Healthy, IF_Kick,
  },
  /* BMBombData */
  {
    bomb_click_none, bomb_click_none, bomb_click_none,
    GoStop, FUSEnormal,
    BMTnormal, BMTnormal, BMTnormal,
  },
  /* BMGraphicsData */
  {
    {
      { "dark_way",   "Black", "OliveDrab", "Tan" },
      { "dark_way_S", "Black", "OliveDrab", "Tan" },
      { "r_i_p",       "Black", "Peru", "OliveDrab" },
      { "r_i_p_R",   "Black", "Peru", "OliveDrab" },
      { "pumpkin",   "Black", "Orange", "OliveDrab" },
      { "pumpkin_O", "Black", "Orange", "OliveDrab" },
      EXTRA_BOMB,
      EXTRA_RANGE,
      EXTRA_TRAP,
      EXTRA_SLOW,
      { "score_floor",     "Black", "White", "Gray50" },
    },
  },
  /* BMMapData */
  {
    ShadowFull, DEall,
    { 16, 32, 40, 50, 58 },
    {
      { B,B,B,B,B,B,B,B,B,B,B,B,B },
      { B,q,q,X,b,_,_,_,b,X,q,q,B },
      { B,q,B,_,_,B,_,B,_,_,B,q,B },
      { B,X,_,X,_,_,X,_,_,X,_,X,B },
      { B,r,_,_,X,_,X,_,X,_,_,r,B },
      { B,r,_,_,_,B,_,B,_,_,_,X,B },
      { B,B,B,_,_,_,X,_,_,_,B,q,B },
      { B,q,q,X,_,_,X,_,_,X,q,q,B },
      { B,q,B,_,_,_,X,_,_,_,B,B,B },
      { B,X,_,_,_,B,_,B,_,_,_,r,B },
      { B,r,_,_,X,_,X,_,X,_,_,r,B },
      { B,X,_,X,_,_,X,_,_,X,_,X,B },
      { B,q,B,_,_,B,_,B,_,_,B,q,B },
      { B,q,q,X,b,_,_,_,b,X,q,q,B },
      { B,B,B,B,B,B,B,B,B,B,B,B,B }  
    },
  },
};
