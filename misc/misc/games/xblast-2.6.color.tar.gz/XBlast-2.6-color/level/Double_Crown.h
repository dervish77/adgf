/* XBlast 2.5.3 level */
/* File: level/Double_Crown.h */
/* Author: Stephan Natschlaeger */
/* Version: 12.1.1998 */
static BMPosition Double_Crown_Del[] = { 
  {5,5}, {5,9}, {7,5}, {7,9}, };
static BMLevelData Double_Crown =
{
  /* BMLevel */
  {
    "Double Crown",
    "Stn",
    "xblast.useDoubleCrown",
    "The King Has Lost His Crowns",
    GM_2456_Player | GM_All,
    (void *) &Double_Crown,
    NULL,
  },
  /* BMShrinkData */
  {
    shrink_spiral,
    SCRAMBLE_VOID,
    { 11*GAME_TIME/20, 4, Double_Crown_Del, },
  },
  /* BMFuncData */
  {
    special_init_void,
    special_game_void,
    special_extra_void,
    special_key_air,
  },
  /* BMPlayerData */
  {
    3, 7,
    {
      {  4,  5 },
      {  4,  9 },
      {  8,  9 },
      {  8,  5 },
      {  6,  7 },
      {  6,  7 },
    },
    PM_Same, 0,
    Healthy, Healthy, IF_Airpump,
  },
  /* BMBombData */
  {
    bomb_click_none, bomb_click_none, bomb_click_thru,
    GoStop, FUSEnormal,
    BMTfungus, BMTnormal, BMTnormal,
  },
  /* BMGraphicsData */
  {
    {
      { "iron_floor", "Black", "Gold", "OrangeRed" },
      { "iron_floor_S", "Black", "Magenta", "OrangeRed" },
      { "dark_block", "Black", "Gold", "LightSkyBlue" },
      { "dark_block_R", "Black", "Yellow", "Red" },
      { "extra", "Black", "SaddleBrown", "Black" },
      { "extra_O", "Black", "SaddleBrown", "Black" },
      EXTRA_BOMB,
      EXTRA_RANGE,
      EXTRA_TRAP,
      EXTRA_KICK,
      { "score_floor", "RoyalBlue", "RoyalBlue", "RoyalBlue" },
    },
  },
  /* BMMapData */
  {
    ShadowExtra, DEall,
    { 0, 0, 0, 0, 0 },
    {
      { B,B,B,B,B,B,B,B,B,B,B,B,B, },
      { B,_,_,_,_,_,_,_,_,_,_,_,B, },
      { B,_,B,_,_,_,_,_,_,_,B,_,B, },
      { B,_,_,B,B,B,_,B,B,B,_,_,B, },
      { B,_,B,_,_,B,_,B,_,_,B,_,B, },
      { B,_,_,_,_,B,_,B,_,_,_,_,B, },
      { B,_,B,_,_,B,_,B,_,_,B,_,B, },
      { B,_,_,B,B,B,_,B,B,B,_,_,B, },
      { B,_,B,_,_,B,_,B,_,_,B,_,B, },
      { B,_,_,_,_,B,_,B,_,_,_,_,B, },
      { B,_,B,_,_,B,_,B,_,_,B,_,B, },
      { B,_,_,B,B,B,_,B,B,B,_,_,B, },
      { B,_,B,_,_,_,_,_,_,_,B,_,B, },
      { B,_,_,_,_,_,_,_,_,_,_,_,B, },
      { B,B,B,B,B,B,B,B,B,B,B,B,B, },
    },
  },
};
