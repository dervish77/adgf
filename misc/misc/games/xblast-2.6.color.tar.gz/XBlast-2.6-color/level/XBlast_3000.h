/* XBlast 2.5.3 level */
static BMLevelData XBlast_3000 =
{
  /* BMLevel */
  {
    "XBlast 3000",
    "The Adelaide Group",
    "xblast.useXBlast3000",
    "Stunned = Loose a life.",
    GM_Random | GM_234_Player | GM_All,
    (void *) &XBlast_3000,
    NULL,
  },
  /* BMShrinkData */
  {
    shrink_spiral_3,
    SCRAMBLE_VOID,
    SCRAMBLE_VOID,
  },
  /* BMFuncData */
  {
    special_init_void,
    special_game_void,
    special_extra_long_stunned,
    special_key_void,
  },
  /* BMPlayerData */
  {
    1, 4,
    {
      {  3,  3 },
      {  3, 11 },
      {  9, 11 },
      {  9,  3 },
    },
    PM_Vertical, -2,
    Healthy, Healthy, IF_None,
  },
  /* BMBombData */
  {
    bomb_click_none, bomb_click_none, bomb_click_none,
    GoStop, FUSEnormal,
    BMTnormal, BMTnormal, BMTnormal,
  },
  /* BMGraphicsData */
  {
    {
      { "sphere_half",     "Black", "LightSteelBlue", "OrangeRed" },
      { "sphere_half_S",   "Black", "LightSteelBlue", "OrangeRed" },
      { "sphere_dark",     "Black", "OrangeRed", "Black" },
      { "sphere_light",    "Black", "Coral", "Black" },
      { "sphere_light",    "Black", "Coral", "Black" },
      { "sphere_light_O",  "Black", "Coral", "Black" },
      EXTRA_BOMB,
      EXTRA_RANGE,
      EXTRA_TRAP,
      { "sphere_half",     "Black", "LightSteelBlue", "OrangeRed" },
      { "score_floor",     "Black", "White", "Gray50" },
    },
  },
  /* BMMapData */
  {
    ShadowFull, DEdouble,
    { 15, 30, 35, 54, 62 },
    {
      { B,B,B,B,B,B,B,B,B,B,B,B,B },
      { B,X,_,_,X,_,B,_,X,_,_,X,B },
      { B,_,B,_,B,X,B,X,B,_,B,_,B },
      { B,_,X,_,X,_,X,_,X,_,X,_,B },
      { B,X,B,X,B,X,B,X,B,X,B,X,B },
      { B,_,X,_,X,_,X,_,X,_,X,_,B },
      { B,_,B,_,B,_,B,_,B,_,B,_,B },
      { B,B,X,X,X,X,X,X,X,X,X,B,B },
      { B,_,B,_,B,_,B,_,B,_,B,_,B },
      { B,_,X,_,X,_,X,_,X,_,X,_,B },
      { B,X,B,X,B,X,B,X,B,X,B,X,B },
      { B,_,X,_,X,_,X,_,X,_,X,_,B },
      { B,_,B,_,B,X,B,X,B,_,B,_,B },
      { B,X,_,_,X,_,B,_,X,_,_,X,B },
      { B,B,B,B,B,B,B,B,B,B,B,B,B }
    },
  },
};
