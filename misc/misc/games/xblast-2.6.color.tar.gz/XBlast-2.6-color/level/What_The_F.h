/* XBlast 2.5.3 level */
static BMLevelData What_The_F =
{
  /* BMLevel */
  {
    "What The F#@* is This",
    "The Adelaide Group",
    "xblast.useWhatTheF",
    "Disorientation = Death",
    GM_Random | GM_23456_Player | GM_All,
    (void *) &What_The_F,
    NULL,
  },
  /* BMShrinkData */
  {
    shrink_spiral,
    SCRAMBLE_VOID,
    SCRAMBLE_VOID,
  },
  /* BMFuncData */
  {
    special_init_void,
    special_game_void,
    special_extra_void,
    special_key_void,
  },
  /* BMPlayerData */
  {
    10, 10,
    {
      {  1,  1 },
      {  1, 13 },
      { 11, 13 },
      { 11,  1 },
      {  3,  7 },
      {  9,  7 },
    },
    PM_Inner, 8,
    Healthy, Healthy, IF_Kick,
  },
  /* BMBombData */
  {
    bomb_click_none, bomb_click_none, bomb_click_none,
    GoStop, FUSEnormal,
    BMTnormal, BMTnormal, BMTnormal,
  },
  /* BMGraphicsData */
  {
    {
      { "dark_block",     "Black", "Gray50",  "White" },
      { "dark_block",     "Black", "Gray50",  "White" },
      { "dark_block",     "Black", "Gray50", "White" },
      { "dark_block_R",   "Black", "Gray50", "White" },
      { "extra",          "Black", "Gray50", "White" },
      { "extra_O",        "Black", "Gray50", "White" },
      EXTRA_BOMB,
      EXTRA_RANGE,
      EXTRA_TRAP,
      EXTRA_KICK,
      { "score_floor",    "Black", "Gray50", "White" },
    },
  },
  /* BMMapData */
  {
    ShadowBlock, DEall,
    { 0, 0, 0, 0, 0 },
    {
      { B,B,B,B,B,B,B,B,B,B,B,B,B },
      { B,_,_,_,_,_,_,_,_,_,_,_,B },
      { B,_,B,_,B,_,B,_,B,_,B,_,B },
      { B,_,_,_,_,_,_,_,_,_,_,_,B },
      { B,_,B,_,B,_,B,_,B,_,B,_,B },
      { B,_,_,_,_,_,_,_,_,_,_,_,B },
      { B,_,B,_,B,_,B,_,B,_,B,_,B },
      { B,_,_,_,_,_,_,_,_,_,_,_,B },
      { B,_,B,_,B,_,B,_,B,_,B,_,B },
      { B,_,_,_,_,_,_,_,_,_,_,_,B },
      { B,_,B,_,B,_,B,_,B,_,B,_,B },
      { B,_,_,_,_,_,_,_,_,_,_,_,B },
      { B,_,B,_,B,_,B,_,B,_,B,_,B },
      { B,_,_,_,_,_,_,_,_,_,_,_,B },
      { B,B,B,B,B,B,B,B,B,B,B,B,B }
    },
  },
};
