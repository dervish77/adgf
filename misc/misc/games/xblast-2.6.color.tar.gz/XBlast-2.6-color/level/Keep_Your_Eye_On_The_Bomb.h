/* XBlast 2.5.3 level */
static BMLevelData Keep_Your_Eye_On_The_Bomb =
{
  /* BMLevel */
  {
    "Keep Your Eye on the Bomb",
    "The Adelaide Group",
    "xblast.useKeepYourEyeOnTheBomb",
    "Umm, did you read the name?",
    GM_Random | GM_23456_Player | GM_All,
    (void *) &Keep_Your_Eye_On_The_Bomb,
    NULL,
  },
  /* BMShrinkData */
  {
    shrink_spiral,
    SCRAMBLE_VOID,
    SCRAMBLE_VOID,
  },
  /* BMFuncData */
  {
    special_init_void,
    special_game_void,
    special_extra_void,
    special_key_air,
  },
  /* BMPlayerData */
  {
    5, 10,
    {
      {  1,  1 },
      {  1, 13 },
      { 11, 13 },
      { 11,  1 },
      {  3,  7 },
      {  9,  7 },
    },
    PM_Inner, 2,
    Healthy, Healthy, IF_Kick,
  },
  /* BMBombData */
  {
    bomb_click_none, bomb_click_none, bomb_click_none,
    GoStop, FUSEnormal,
    BMTnormal, BMTnormal, BMTnormal,
  },
  /* BMGraphicsData */
  {
    {
      { "bomb_floor", NULL, "SteelBlue",  "DarkSlateGray" },
      { "bomb_floor", NULL, "SteelBlue",  "DarkSlateGray" },
      { "dark_block",     "Black", "SeaGreen", "NavyBlue" },
      { "dark_block_R", "Black", "NavyBlue", "SeaGreen" },
      { "extra",         "Black", "Gray50", "White" },
      { "extra_O",       "Black", "Gray50", "White" },
      EXTRA_BOMB,
      EXTRA_RANGE,
      EXTRA_TRAP,
      EXTRA_KICK,
      { "score_floor",    "Black", "Gray50", "White" },
    },
  },
  /* BMMapData */
  {
    ShadowBlock, DEall,
    { 0, 0, 0, 0, 0 },
    {
      { B,B,B,B,B,B,B,B,B,B,B,B,B },
      { B,_,_,_,_,_,_,_,_,_,_,_,B },
      { B,_,B,_,B,_,B,_,B,_,B,_,B },
      { B,_,_,_,_,_,_,_,_,_,_,_,B },
      { B,_,B,_,B,_,B,_,B,_,B,_,B },
      { B,_,_,_,_,_,_,_,_,_,_,_,B },
      { B,_,B,_,B,_,B,_,B,_,B,_,B },
      { B,_,_,_,_,_,_,_,_,_,_,_,B },
      { B,_,B,_,B,_,B,_,B,_,B,_,B },
      { B,_,_,_,_,_,_,_,_,_,_,_,B },
      { B,_,B,_,B,_,B,_,B,_,B,_,B },
      { B,_,_,_,_,_,_,_,_,_,_,_,B },
      { B,_,B,_,B,_,B,_,B,_,B,_,B },
      { B,_,_,_,_,_,_,_,_,_,_,_,B },
      { B,B,B,B,B,B,B,B,B,B,B,B,B }
    },
  },
};
