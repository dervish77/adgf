/* XBlast 2.5.3 level */
/* File: level/Random.h */
/* Author: Stephan Natschlaeger */
/* Version: 5.1.1998 */
static BMLevelData Random =
{
  /* BMLevel */
  {
    "Random",
    "Stn",
    "xblast.useRandom",
    "Bombs Move Unpredictably",
    GM_Random | GM_23456_Player | GM_All,
    (void *) &Random,
    NULL,
  },
  /* BMShrinkData */
  {
    shrink_void,
    SCRAMBLE_VOID,
    SCRAMBLE_VOID,
  },
  /* BMFuncData */
  {
    special_init_void,
    special_game_void,
    special_extra_kick,
    special_key_void,
  },
  /* BMPlayerData */
  {
    5, 10,
    {
      {  1,  1 },
      {  1, 13 },
      { 11, 13 },
      { 11,  1 },
      {  5,  7 },
      {  7,  7 },
    },
    PM_Same, 0,
    Healthy, Healthy, IF_Kick,
  },
  /* BMBombData */
  {
    bomb_click_randomdir, bomb_click_randomdir, bomb_click_none,
    GoStop, FUSElong,
    BMTnormal, BMTnormal, BMTnormal,
  },
  /* BMGraphicsData */
  {
    {
      { "iron_floor", "Black", "DarkSlateBlue", "OrangeRed" },
      { "iron_floor_S", "Black", "DarkSlateBlue", "OrangeRed" },
      { "dark_block", "Red", "OrangeRed", "Orange" },
      { "dark_block_R", "Red", "OrangeRed", "Orange" },
      { "extra", "Black", "SaddleBrown", "Black" },
      { "extra", "Black", "SaddleBrown", "Black" },
      EXTRA_BOMB,
      EXTRA_RANGE,
      EXTRA_TRAP,
      EXTRA_KICK,
      { "score_floor", "RoyalBlue", "RoyalBlue", "RoyalBlue" },
    },
  },
  /* BMMapData */
  {
    ShadowExtra, 
    DEall,
    { 0, 0, 0, 0, 0 },
    {
      { B,B,B,B,B,B,B,B,B,B,B,B,B, },
      { B,_,_,_,_,_,_,_,_,_,_,_,B, },
      { B,_,_,_,_,_,B,_,_,_,_,_,B, },
      { B,_,_,B,_,_,_,_,_,B,_,_,B, },
      { B,_,_,_,_,_,_,_,_,_,_,_,B, },
      { B,_,_,_,_,B,_,B,_,_,_,_,B, },
      { B,_,B,_,_,_,_,_,_,_,B,_,B, },
      { B,_,_,_,_,_,B,_,_,_,_,_,B, },
      { B,_,B,_,_,_,_,_,_,_,B,_,B, },
      { B,_,_,_,_,B,_,B,_,_,_,_,B, },
      { B,_,_,_,_,_,_,_,_,_,_,_,B, },
      { B,_,_,B,_,_,_,_,_,B,_,_,B, },
      { B,_,_,_,_,_,B,_,_,_,_,_,B, },
      { B,_,_,_,_,_,_,_,_,_,_,_,B, },
      { B,B,B,B,B,B,B,B,B,B,B,B,B, },
    },
  },
};
