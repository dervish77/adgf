/* XBlast 2.5.3 level */
/* File: level/Magic.h */
/* Author: Stephan Natschlaeger */
/* Version: 16.12.1997 */
static BMLevelData Magic =
{
  /* BMLevel */
  {
    "Magic",
    "Stn",
    "xblast.useMagic",
    "Do You Know Where The Others Are?",
    GM_Random | GM_23456_Player | GM_All,
    (void *) &Magic,
    NULL,
  },
  /* BMShrinkData */
  {
    shrink_spiral,
    SCRAMBLE_VOID,
    SCRAMBLE_VOID,
  },
  /* BMFuncData */
  {
    special_init_void,
    special_game_haunt,
    special_extra_void,
    special_key_cloak,
  },
  /* BMPlayerData */
  {
    2, 1,
    {
      {  6,  6 },
      {  6,  8 },
      {  2,  3 },
      {  2, 11 },
      { 10,  3 },
      { 10, 11 },
    },
    PM_Same, 0,
    Healthy, Healthy, IF_Cloak,
  },
  /* BMBombData */
  {
    bomb_click_none, bomb_click_none, bomb_click_thru,
    GoStop, FUSEnormal,
    BMTnormal, BMTnormal, BMTnormal,
  },
  /* BMGraphicsData */
  {
    {
      { "iron_floor",     "Black",     "CornflowerBlue",  "OrangeRed" },
      { "iron_floor_S",   "Black",     "CornflowerBlue",  "OrangeRed" },
      { "dark_block",     "Black",     "CadetBlue2",      "Magenta" },
      { "dark_block_R",   "Black",     "CadetBlue2",      "Green" },
      { "extra",          "Black",     "Firebrick",       "Black" },
      { "extra",          "Black",     "Firebrick",       "Black" },
      EXTRA_BOMB,
      EXTRA_RANGE,
      EXTRA_TRAP,
      EXTRA_CLOAK,
      { "score_floor",    "SteelBlue", "SteelBlue", "RoyalBlue" },
    },
  },
  /* BMMapData */
  {
    ShadowFull, DEall,
    { 30, 40, 50, 50, 60 },
    {
      { B,B,B,B,B,B,B,B,B,B,B,B,B, },
      { B,_,_,_,_,_,_,_,_,_,_,_,B, },
      { B,_,B,B,B,X,_,X,B,B,B,_,B, },
      { B,X,_,_,X,_,B,_,X,_,_,X,B, },
      { B,_,B,_,B,_,B,_,B,_,B,_,B, },
      { B,_,_,_,B,_,_,_,B,_,_,_,B, },
      { B,_,_,_,X,_,_,_,X,_,_,_,B, },
      { B,B,B,B,_,X,B,X,_,B,B,B,B, },
      { B,_,_,_,X,_,_,_,X,_,_,_,B, },
      { B,_,_,_,B,_,_,_,B,_,_,_,B, },
      { B,_,B,_,B,_,B,_,B,_,B,_,B, },
      { B,X,_,_,X,_,B,_,X,_,_,X,B, },
      { B,_,B,B,B,X,_,X,B,B,B,_,B, },
      { B,_,_,_,_,_,_,_,_,_,_,_,B, },
      { B,B,B,B,B,B,B,B,B,B,B,B,B, },
    },
  },
};
