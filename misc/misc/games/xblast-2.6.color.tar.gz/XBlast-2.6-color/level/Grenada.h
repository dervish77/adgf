/* XBlast 2.5.3 level */
/* File: level/Grenada.h */
/* Author: Stephan Natschlaeger */
/* Version: 7.1.1998 */
static BMLevelData Grenada =
{
  /* BMLevel */
  {
    "Grenada",
    "Stn",
    "xblast.useGrenada",
    "Grenades Explode When Hitting Land",
    GM_Random | GM_23456_Player | GM_All,
    (void *) &Grenada,
    NULL,
  },
  /* BMShrinkData */
  {
    shrink_spiral,
    SCRAMBLE_VOID,
    SCRAMBLE_VOID,
  },
  /* BMFuncData */
  {
    special_init_void,
    special_game_void,
    special_extra_kick,
    special_key_void,
  },
  /* BMPlayerData */
  {
    2, 2,
    {
      {  1,  1 },
      {  1, 13 },
      { 11, 13 },
      { 11,  1 },
      {  1,  6 },
      { 11,  6 },
    },
    PM_Same, 0,
    Healthy, Healthy, IF_None,
  },
  /* BMBombData */
  {
    bomb_click_none, bomb_click_contact, bomb_click_none,
    GoStop, FUSEnormal,
    BMTgrenade, BMTnormal, BMTnormal,
  },
  /* BMGraphicsData */
  {
    {
      { "karo_light",   "Black", "SlateBlue", "SteelBlue" },
      { "karo_light_S", "Black", "SlateBlue", "SteelBlue" },
      { "pyramid",     "Black", "Goldenrod", "Goldenrod" },
      { "pyramid_R", "Black", "Goldenrod", "LightGoldenrod" },
      { "extra",       "Black", "Sienna",    "Orange" },
      { "extra_O",     "Black", "Sienna",    "Orange" },
      EXTRA_BOMB,
      EXTRA_RANGE,
      EXTRA_TRAP,
      EXTRA_KICK,
      { "score_floor", "RoyalBlue", "RoyalBlue", "RoyalBlue" },
    },
  },
  /* BMMapData */
  {
    ShadowFull, DEall,
    { 15, 25, 35, 50, 60 },
    {
      { B,B,B,B,B,B,B,B,B,B,B,B,B, },
      { B,_,_,_,X,_,_,_,X,_,_,_,B, },
      { B,_,_,X,B,B,X,B,B,X,_,_,B, },
      { B,X,X,X,_,_,_,_,_,X,X,X,B, },
      { B,B,_,_,_,_,_,_,_,_,_,B,B, },
      { B,X,X,_,B,B,X,B,B,X,X,X,B, },
      { B,_,X,B,_,_,_,_,_,X,_,_,B, },
      { B,_,_,X,_,_,X,_,_,X,_,_,B, },
      { B,_,_,X,_,_,_,_,_,B,X,_,B, },
      { B,X,X,X,B,B,X,B,B,X,X,X,B, },
      { B,B,_,_,_,_,_,_,_,_,_,B,B, },
      { B,X,X,X,_,_,_,_,_,X,X,X,B, },
      { B,_,_,X,B,B,X,B,B,X,_,_,B, },
      { B,_,_,_,X,_,_,_,X,_,_,_,B, },
      { B,B,B,B,B,B,B,B,B,B,B,B,B, },
    },
  },
};
