/* XBlast 2.5.3 level */
static BMLevelData MazeRunner =
{
  /* BMLevel */
  {
    "Maze Runner",
    "Peel & Killer",
    "xblast.useMazeRunner",
    "Don't try to hide",
    GM_Random | GM_23456_Player | GM_All,
    (void *) &MazeRunner,
    NULL,
  },
  /* BMShrinkData */
  {
    shrink_void,
    SCRAMBLE_VOID,
    SCRAMBLE_VOID,
  },
  /* BMFuncData */
  {
    special_init_special_bombs_30,
    special_game_void,
    special_extra_special_bomb,
    special_key_special_bomb,
  },
  /* BMPlayerData */
  {
    3, 2,
    {
      { 1, 1 },
      { 1, 13 },
      { 11, 13 },
      { 11, 1 },
      { 3, 1 },
      { 9, 13 },
    },
    PM_Polar, 2,
    IllRun, IllRun, IF_Kick,
  },
  /* BMBombData */
  {
    bomb_click_snooker, bomb_click_none, bomb_click_none,
    GoStop, FUSEnormal,
    BMTnormal, BMTpyro, BMTnormal,
  },
  /* BMGraphicsData */
  {
    {
      { "hex", "Black", "Red", "White" },
      { "hex", "Black", "Red", "White" },
      { "hex_wall", "Black", "Red", "DarkTurquoise" },
      { "hex_wall", "Black", "Red", "DarkTurquoise" },
      { "hex_extra", "Black", "Red", "Gray80" },
      { "hex_extra_O", "Black", "Red", "Gray80" },
      EXTRA_BOMB,
      EXTRA_RANGE,
      EXTRA_TRAP,
      EXTRA_RC,
      { "score_floor", "Red", "Red", "RoyalBlue" },
    },
  },
  /* BMMapData */
  {
    ShadowFull, DEsingle,
    {16,32,48,48,56},
    {
      { B,B,B,B,B,B,B,B,B,B,B,B,B, },
      { B,_,B,_,_,B,_,_,_,_,_,_,B, },
      { B,_,B,B,_,B,B,B,B,_,B,_,B, },
      { B,_,B,_,_,_,_,_,B,_,B,_,B, },
      { B,_,B,_,B,_,_,_,B,_,B,_,B, },
      { B,_,B,_,_,_,B,_,_,_,B,B,B, },
      { B,_,B,_,_,_,_,_,B,_,_,_,B, },
      { B,_,B,B,B,_,_,_,B,B,B,_,B, },
      { B,_,_,_,B,_,_,_,_,_,B,_,B, },
      { B,B,B,_,_,_,B,_,_,_,B,_,B, },
      { B,_,B,_,B,_,_,_,B,_,B,_,B, },
      { B,_,B,_,B,_,_,_,_,_,B,_,B, },
      { B,_,B,_,B,B,B,B,_,B,B,_,B, },
      { B,_,_,_,_,_,_,B,_,_,B,_,B, },
      { B,B,B,B,B,B,B,B,B,B,B,B,B, },
    },
  },
};
