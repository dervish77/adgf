/* XBlast 2.5.3 level */
static BMPosition All_Good_Things_Dele[] = {
 {2,2},{10,2},{2,12},{10,12}};

static BMLevelData All_Good_Things =
{
  /* BMLevel */
  {
    "All Good Things",
    "Keith Gillow and Mark Shepherd",
    "xblast.useAllGoodThings",
    "Find a timer before everyone gets one",
    GM_Random | GM_234_Player | GM_All,
    (void *) &All_Good_Things,
    NULL,
  },
  /* BMShrinkData */
  {
    shrink_spiral,
    SCRAMBLE_VOID,
    {3*GAME_TIME/8, 4, All_Good_Things_Dele},
  },
  /* BMFuncData */
  {
    special_init_void,
    special_game_void,
    special_extra_RC,
    special_key_RC,
  },
  /* BMPlayerData */
  {
    1, 2,
    {
      { 6, 2 },
      { 1 , 7 },
      { 6, 12 },
      { 11, 7 },
    },
    PM_Circle, 1,
    Healthy, Healthy, IF_Kick, 
  },
  /* BMBombData */
  {
    bomb_click_none, bomb_click_none, bomb_click_thru,
    GoStop, FUSEnormal,
    BMTnormal, BMTnormal, BMTnormal,
  },
  /* BMGraphicsData */
  {
    {
      { "chess_floor",   "Black",     "SeaGreen",    "DarkSeaGreen" },
      { "chess_floor_S", "Black",     "Seagreen",    "DarkSeaGreen" },
      { "wall",         "Black",     "Firebrick1",   "Black" },
      { "wall_R",     "Black",     "Firebrick1",   "SeaGreen" },
      { "chest",        "Black",     "SaddleBrown", "Gold" },
      { "chest_O",      "Black",     "SaddleBrown", "Gold" },
      EXTRA_BOMB,
      EXTRA_RANGE,
      EXTRA_TRAP,
      EXTRA_RC,
      { "score_floor", "RoyalBlue", "RoyalBlue",   "RoyalBlue" },
    },
  },
  /* BMMapData */
  {
    ShadowFull, DEsingle,
    {20,40,47,50,56},
    {
      { B,B,B,B,B,B,B,B,B,B,B,B,B },
      { B,q,b,B,X,B,_,B,X,B,b,q,B },
      { B,r,B,X,_,_,_,_,_,X,B,r,B },
      { B,B,X,X,_,_,B,_,_,X,X,B,B },
      { B,X,_,_,B,_,_,_,B,_,_,X,B },
      { B,B,B,_,B,X,_,X,B,_,B,B,B },
      { B,_,B,_,_,B,X,B,_,_,B,_,B },
      { B,_,_,_,_,X,X,X,_,_,_,_,B },
      { B,_,B,_,_,B,X,B,_,_,B,_,B },
      { B,B,B,_,B,X,_,X,B,_,B,B,B },
      { B,X,_,_,B,_,_,_,B,_,_,X,B },
      { B,B,X,X,_,_,B,_,_,X,X,B,B },
      { B,r,B,X,_,_,_,_,_,X,B,r,B },
      { B,q,b,B,X,B,_,B,X,B,b,q,B },
      { B,B,B,B,B,B,B,B,B,B,B,B,B }
    },
  },
};

