/* XBlast 2.5.3 level */
static BMLevelData Close_Quarters =
{
  /* BMLevel */
  {
    "Close Quarters",
    "Oliver Vogel",
    "xblast.useCloseQuarters",
    "Use your fast bombs wisely",
    GM_Random | GM_23456_Player | GM_All,
    (void *) &Close_Quarters,
    NULL,
  },
  /* BMShrinkData */
  {
    shrink_spiral_23,
    SCRAMBLE_VOID,
    SCRAMBLE_VOID,
  },
  /* BMFuncData */
  {
    special_init_special_bombs_12,
    special_game_void,
    special_extra_kick,
    special_key_special_bomb,
  },
  /* BMPlayerData */
  {
    1, 2,
    {
      {  2,  2 },
      {  2, 12 },
      { 10, 12 },
      { 10,  2 },
      {  6,  4 },
      {  6, 10 },
    },
    PM_Polar, 1,
    Healthy, Healthy, IF_None,
  },
  /* BMBombData */
  {
    bomb_click_none, bomb_click_none, bomb_click_none,
    GoStop, FUSEnormal,
    BMTnormal, BMTshort, BMTfungus,
  },
  /* BMGraphicsData */
  {
    {
      { "hex",         "Black", "CornflowerBlue", "OrangeRed" },
      { "hex",         "Black", "CornflowerBlue", "OrangeRed" },
      { "hex_wall",    "Black", "CornflowerBlue", "SteelBlue" },
      { "hex_extra",   "Black", "CornflowerBlue", "LightSteelBlue" },
      { "hex_extra",   "Black", "CornflowerBlue", "Orange" },
      { "hex_extra_O", "Black", "CornflowerBlue", "Orange" },
      EXTRA_BOMB,
      EXTRA_RANGE,
      EXTRA_TRAP,
      EXTRA_KICK,
      { "hex",         "Black", "CornflowerBlue", "BlueViolet" },
    },
  },
  /* BMMapData */
  {
    ShadowNone, DEall,
    { 16, 32, 40, 40, 56 },
    {
      { v,v,v,v,v,v,v,v,v,v,v,v,v, },
      { v,B,B,B,B,B,B,B,B,B,B,B,v, },
      { v,B,_,_,X,X,X,X,X,_,_,B,v, },
      { v,B,_,B,X,B,_,B,X,B,_,B,v, },
      { v,B,X,X,X,_,_,_,X,X,X,B,v, },
      { v,B,X,B,X,B,X,B,X,B,X,B,v, },
      { v,B,X,X,X,X,X,X,X,X,X,B,v, },
      { v,B,X,B,X,B,X,B,X,B,X,B,v, },
      { v,B,X,X,X,X,X,X,X,X,X,B,v, },
      { v,B,X,B,X,B,X,B,X,B,X,B,v, },
      { v,B,X,X,X,_,_,_,X,X,X,B,v, },
      { v,B,_,B,X,B,_,B,X,B,_,B,v, },
      { v,B,_,_,X,X,X,X,X,_,_,B,v, },
      { v,B,B,B,B,B,B,B,B,B,B,B,v, },
      { v,v,v,v,v,v,v,v,v,v,v,v,v, },
    },
  },
};
