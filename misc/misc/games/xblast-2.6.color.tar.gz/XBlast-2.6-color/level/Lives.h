/* XBlast 2.5.3 level */
static BMLevelData Lives =
{
  /* BMLevel */
  {
    "Lives",
    "The Adelaide Group",
    "xblast.useLives",
    "...",
    GM_Random | GM_234_Player | GM_All,
    (void *) &Lives,
    NULL,
  },
  /* BMShrinkData */
  {
    shrink_spiral,
    SCRAMBLE_VOID,
    SCRAMBLE_VOID,
  },
  /* BMFuncData */
  {
    special_init_void,
    special_game_haunt,
    special_extra_life,
    special_key_void,
  },
  /* BMPlayerData */
  {
    3, 5,
    {
      {  1,  1 },
      {  1, 13 },
      { 11, 13 },
      { 11,  1 },
    },
    PM_Polar, 2,
    IllBomb, IllBomb, IF_Kick,
  },
  /* BMBombData */
  {
    bomb_click_snooker, bomb_click_none, bomb_click_none,
    GoStop, FUSEnormal,
    BMTnormal, BMTnormal, BMTnormal,
  },
  /* BMGraphicsData */
  {
    {
      { "lego_floor",   "Black", "Gray85", "Gray85" },
      { "lego_floor_S", "Black", "Gray85", "Gray85" },
      { "lego_white",   "Black", "Yellow", "Gray85" },
      { "lego_floor",   "Black", "Gray85", "Yellow" }, 
      { "lego_black",   "DarkGreen", "Black", "Gray85" },
      { "lego_black_O", "DarkGreen", "Black", "Gray85" },
      EXTRA_BOMB,
      EXTRA_RANGE,
      EXTRA_TRAP,
      EXTRA_LIFE,
      { "score_floor", "Black", "Gray50", "White" },
    },
  },
  /* BMMapData */
  {
    ShadowFull, DEsingle,
    { 15, 30, 40, 60, 60 },
    {
      { B,B,B,B,B,B,B,B,B,B,B,B,B },
      { B,_,_,_,X,q,q,q,X,_,_,_,B },
      { B,_,B,_,B,X,q,X,B,_,B,_,B },
      { B,_,_,_,X,q,X,q,X,_,_,_,B },
      { B,B,X,X,B,X,q,X,B,X,X,B,B },
      { B,_,X,_,X,q,X,q,X,_,X,_,B },
      { B,X,_,X,_,X,B,X,_,X,_,X,B },
      { B,_,X,_,X,_,X,_,X,_,X,_,B },
      { B,X,_,X,_,X,B,X,_,X,_,X,B },
      { B,_,X,_,X,q,X,q,X,_,X,_,B },
      { B,B,X,X,B,X,q,X,B,X,X,B,B },
      { B,_,_,_,X,q,X,q,X,_,_,_,B },
      { B,_,B,_,B,X,q,X,B,_,B,_,B },
      { B,_,_,_,X,q,q,q,X,_,_,_,B },
      { B,B,B,B,B,B,B,B,B,B,B,B,B }
    },
  },
};
