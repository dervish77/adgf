/* XBlast 2.5.3 level */
static BMLevelData Gravitation_Is_Back =
{
  /* BMLevel */
  {
    "Gravitation is back",
    "M. \"Snoopy\" Fries",
    "xblast.useGravitationIsBack",
    "???",
    GM_Random | GM_234_Player | GM_Single | GM_Team | GM_LR_Players,
    (void *) &Gravitation_Is_Back,
    NULL,
  },
  /* BMShrinkData */
  {
    shrink_down,
    SCRAMBLE_VOID,
    SCRAMBLE_VOID,
  },
  /* BMFuncData */
  {
    special_init_void,
    special_game_void,
    special_extra_void,
    special_key_void,
  },
  /* BMPlayerData */
  {
    1, 2,
    {
      {  1,  1 },
      {  1, 13 },
      {  3, 11 },
      {  3,  3 },
    },
    PM_Same, 0,
    Healthy, Healthy, IF_Kick,
  },
  /* BMBombData */
  {
    bomb_click_none, bomb_click_none, bomb_click_initial,
    GoDown, FUSEshort,
    BMTnormal, BMTnormal, BMTnormal,
  },
  /* BMGraphicsData */
  {
    {
      { "iron_floor", "Black", "Gold", "Red" },
      { "iron_floor_S", "Black", "Gold", "Red" },
      { "dark_block", "Black", "Orchid", "SlateBlue" },
      { "dark_block_R", "Black", "Orchid", "SlateBlue" },
      { "bricks", "Black", "OrangeRed", "Gray50" },
      { "brick_O", "Black", "OrangeRed", "Gray50" },
      EXTRA_BOMB,
      EXTRA_RANGE,
      EXTRA_TRAP,
      { "score_floor", "RoyalBlue", "White", "Gray50" },
      { "score_floor", "RoyalBlue", "White", "Gray50" },
    },
  },
  /* BMMapData */
  {
    ShadowFull, DEall,
    { 12, 28, 28, 26, 36 },
    {
    { B,B,B,B,B,B,B,B,B,B,B,B,B },
    { B,_,B,X,_,_,_,_,_,_,B,_,B },
    { B,X,X,B,_,X,_,_,_,_,B,_,B },
    { B,_,X,_,B,_,_,X,_,_,_,_,B },  
    { B,_,_,X,_,B,_,_,_,X,_,X,B },
    { B,_,X,_,_,_,B,_,_,_,X,X,B },   
    { B,_,_,_,X,_,_,B,_,X,X,B,B },  
    { B,_,_,X,_,_,X,X,X,X,B,X,B },   
    { B,_,_,_,X,_,_,B,_,X,X,B,B },  
    { B,_,X,_,_,_,B,_,_,_,X,X,B },   
    { B,_,_,X,_,B,_,_,_,X,_,X,B },
    { B,_,X,_,B,_,_,X,_,_,_,_,B },  
    { B,X,X,B,_,X,_,_,_,_,B,_,B },
    { B,_,B,X,_,_,_,_,_,_,B,_,B },
    { B,B,B,B,B,B,B,B,B,B,B,B,B }
    },
  },
};
