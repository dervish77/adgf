/* XBlast 2.6.beta level
 * Level created by Storch 1.00
 * Written by Tobias Johansson (d97tj@efd.lth.se)
 * "Screw Him!" is created by Arno van Leest, april '98
 */

static BMLevelData ScrewHim =
{
  /* BMLevel */
  {
    "Screw Him!",
    "Arno van Leest",
    "xblast.useScrewHim",
    "Shag him!",
    GM_Random | GM_23456_Player | GM_All,
    (void *) &ScrewHim,
    NULL,
  },
  /* BMShrinkData */
  {
    shrink_void,
    SCRAMBLE_VOID,
    SCRAMBLE_VOID,
  },
  /* BMFuncData */
  {
  special_init_void,
  special_game_void,
  special_extra_void,
  special_key_void,
  },
  /* BMPlayerData */
  {
    5, 2,
    {
      { 6, 7 },
      { 6, 7 },
      { 6, 7 },
      { 6, 7 },
      { 6, 7 },
      { 6, 7 },
    },
    PM_Polar, 2,
    Healthy, Healthy, IF_Kick,
  },
  /* BMBombData */
  {
    bomb_click_snooker, bomb_click_anticlockwise, bomb_click_none,
    GoStop, FUSEnormal,
    BMTnormal, BMTnormal, BMTnormal,
  },
  /* BMGraphicsData */
  {
    {
      { "karo_light", "Black", "Orchid", "DarkOrchid" },
      { "karo_light_S", "Black", "Orchid", "DarkOrchid" },
      { "pyramid", "Black", "SlateBlue", "Black" },
      { "pyramid_R", "Black", "LightSlateBlue", "Black" },
      { "extra", "Black", "Gold", "Yellow" },
      { "extra_O", "Black", "Gold", "Yellow" },
      EXTRA_BOMB,
      EXTRA_RANGE,
      EXTRA_TRAP,
      EXTRA_BOMB,
      { "score_floor", "RoyalBlue", "RoyalBlue", "RoyalBlue" },
    },
  },
  /* BMMapData */
  {
      ShadowFull, DEnone,
      { 0, 0, 0, 0, 0 },
      {
      { B,B,B,B,B,B,B,B,B,B,B,B,B, },
      { B,B,B,B,B,_,_,_,_,_,B,B,B, },
      { B,B,B,B,B,_,_,_,_,_,B,B,B, },
      { B,B,B,B,B,_,_,_,_,_,B,B,B, },
      { B,B,B,B,B,_,B,B,B,B,B,B,B, },
      { B,_,_,_,B,_,_,_,_,_,_,_,B, },
      { B,_,_,_,B,_,_,_,B,_,_,_,B, },
      { B,_,_,_,B,_,_,_,B,_,_,_,B, },
      { B,_,_,_,B,_,_,_,B,_,_,_,B, },
      { B,_,_,_,_,_,_,_,B,_,_,_,B, },
      { B,B,B,B,B,B,B,_,B,B,B,B,B, },
      { B,B,B,_,_,_,_,_,B,B,B,B,B, },
      { B,B,B,_,_,_,_,_,B,B,B,B,B, },
      { B,B,B,_,_,_,_,_,B,B,B,B,B, },
      { B,B,B,B,B,B,B,B,B,B,B,B,B, },
    },
  },
};

