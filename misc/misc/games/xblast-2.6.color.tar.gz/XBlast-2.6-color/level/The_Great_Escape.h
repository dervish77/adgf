/* XBlast 2.5.3 level */
static BMLevelData The_Great_Escape =
{
  /* BMLevel */
  {
    "The Great Escape",
    "The Adelaide Group",
    "xblast.useTheGreatEscape",
    "Go on the attack or it WILL be a draw. Use the speed.",
    GM_Random | GM_234_Player | GM_All,
    (void *) &The_Great_Escape,
    NULL,
  },
  /* BMShrinkData */
  {
    shrink_spiral,
    SCRAMBLE_VOID,
    SCRAMBLE_VOID,
  },
  /* BMFuncData */
  {
    special_init_void,
    special_game_void,
    special_extra_speed,
    special_key_void,
  },
  /* BMPlayerData */
  {
    3, 2,
    {
      {  4,  2 },
      {  2, 10 },
      {  8, 12 },
      { 10,  4 },
    },
    PM_Inner, 1,
    Healthy, Healthy, IF_Kick,
  },
  /* BMBombData */
  {
    bomb_click_none, bomb_click_none, bomb_click_none,
    GoStop, FUSEnormal,
    BMTnormal, BMTnormal, BMTnormal,
  },
  /* BMGraphicsData */
  {
    {
      { "iron_floor",      "Black", "Lavender", "Turquoise" },
      { "iron_floor_S",    "Black", "Lavender", "Turquoise" },
      { "dark_block",      "Black", "SeaGreen", "MediumSeaGreen" },
      { "dark_block_R",  "Black",   "SeaGreen", "MediumSeaGreen" },
      { "extra",          "Black", "SteelBlue", "DeepSkyBlue" },
      { "extra_O",        "Black", "SteelBlue", "DeepSkyBlue" },
      EXTRA_BOMB,
      EXTRA_RANGE,
      EXTRA_TRAP,
      EXTRA_SPEED,
      { "score_floor",     "Black", "White", "Gray50" },
    },
  },
  /* BMMapData */
  {
    ShadowFull, DEall,
    { 16, 32, 39, 48, 48 },
    {
      { B,B,B,B,B,B,B,B,B,B,B,B,B },
      { B,X,X,X,_,_,X,X,X,_,B,X,B },
      { B,B,B,B,_,B,B,B,B,_,B,X,B },
      { B,X,_,X,B,_,X,_,_,_,B,X,B },
      { B,B,B,_,_,_,B,_,B,B,_,_,B },
      { B,_,_,_,B,_,_,X,_,_,B,_,B },
      { B,X,B,B,X,_,B,_,B,_,B,X,B },
      { B,X,B,_,_,X,_,X,_,_,B,X,B },
      { B,X,B,_,B,_,B,_,X,B,B,X,B },
      { B,_,B,_,_,X,_,_,B,_,_,_,B },
      { B,_,_,B,B,_,B,_,_,_,B,B,B },
      { B,X,B,_,_,_,X,_,B,X,_,X,B },
      { B,X,B,_,B,B,B,B,_,B,B,B,B },
      { B,X,B,_,X,X,X,_,_,X,X,X,B },
      { B,B,B,B,B,B,B,B,B,B,B,B,B }
    },
  },
};
