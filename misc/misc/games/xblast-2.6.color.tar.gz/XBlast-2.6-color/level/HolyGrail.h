/* XBlast 2.5.3 level */
static BMLevelData HolyGrail =
{
  /* BMLevel */
  {
    "The Holy Grail",
    "The Adelaide Group",
    "xblast.useHolyGrail",
    "Run like shit to get the grail.",
    GM_Random | GM_234_Player | GM_All,
    (void *) &HolyGrail,
    NULL,
  },
  /* BMShrinkData */
  {
    shrink_spiral,
    SCRAMBLE_VOID,
    SCRAMBLE_VOID,
  },
  /* BMFuncData */
  {
    special_init_void,
    special_game_void,
    special_extra_holy_grail,
    special_key_void,
  },
  /* BMPlayerData */
  {
    1, 1,
    {
      {  1,  2 },
      {  1, 12 },
      { 11, 12 },
      { 11,  2 },
    },
    PM_Horizontal, 2,
    Healthy, Healthy, IF_None,
  },
  /* BMBombData */
  {
    bomb_click_none, bomb_click_none, bomb_click_none,
    GoStop, FUSEnormal,
    BMTnormal, BMTnormal, BMTnormal,
  },
  /* BMGraphicsData */
  {
    {
#if 0
      { "karo_dark",   "Black", "OrangeRed",      "Yellow" },
      { "karo_dark_S", "Black", "OrangeRed",      "Yellow" },
      { "wall",        "Black", "LimeGreen", "ForestGreen" },
      { "wall_R",      "Black", "LimeGreen", "Yellow" },
      { "chest",       "Black", "SlateBlue",    "Gold" },
      { "chest_O",     "Black", "SlateBlue",    "Gold" },
#else
      { "karo_dark",   "Black", "Azure",      "SlateGray" },
      { "karo_dark_S", "Black", "Azure",      "SlateGray" },
      { "wall",        "Black", "LimeGreen", "ForestGreen" },
      { "wall_R",      "Black", "LimeGreen", "Yellow" },
      { "chest",       "Black", "SlateBlue",    "Gold" },
      { "chest_O",     "Black", "SlateBlue",    "Gold" },
#endif
      EXTRA_BOMB,
      EXTRA_RANGE,
      EXTRA_TRAP,
      EXTRA_HOLYGRAIL,
      { "score_floor", "Black", "White", "Gray50" },
    },
  },
  /* BMMapData */
  {
    ShadowFull, DEget,
    { 32, 48, 48, 48, 48 },
    {
      { B,B,B,B,B,B,B,B,B,B,B,B,B },
      { B,X,X,_,X,B,_,B,X,_,X,X,B },
      { B,_,B,X,B,B,X,B,B,X,B,_,B },
      { B,_,B,X,X,_,_,_,X,X,B,_,B },
      { B,_,X,X,B,X,B,X,B,X,X,_,B },
      { B,X,B,B,X,_,_,_,X,B,B,X,B },
      { B,_,B,_,B,X,B,X,B,_,B,_,B },
      { B,X,X,X,X,X,q,X,X,X,X,X,B },
      { B,_,B,_,B,X,B,X,B,_,B,_,B },
      { B,X,B,B,X,_,_,_,X,B,B,X,B },
      { B,_,X,X,B,X,B,X,B,X,X,_,B },
      { B,_,B,X,X,_,_,_,X,X,B,_,B },
      { B,_,B,X,B,B,X,B,B,X,B,_,B },
      { B,X,X,_,X,B,_,B,X,_,X,X,B },
      { B,B,B,B,B,B,B,B,B,B,B,B,B }
    },
  },
};
