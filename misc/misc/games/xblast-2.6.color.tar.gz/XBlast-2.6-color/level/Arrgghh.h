/* XBlast 2.5.3 level */
static BMLevelData Arrgghh =
{
  /* BMLevel */
  {
    "Arrgghh!!!",
    "The Adelaide Group",
    "xblast.useArrgghh",
    "Suicide on others when you get killed.",
    GM_Random | GM_23456_Player | GM_All,
    (void *) &Arrgghh,
    NULL,
  },
  /* BMShrinkData */
  {
    shrink_spiral,
    SCRAMBLE_VOID,
    SCRAMBLE_VOID,
  },
  /* BMFuncData */
  {
    special_init_void,
    special_game_void,
    special_extra_void,
    special_key_RC,
  },
  /* BMPlayerData */
  {
    5, 2,
    {
      {  2,  2 },
      {  2, 12 },
      { 10, 12 },
      { 10,  2 },
      {  4,  7 },
      {  8,  7 },
    },
    PM_Inner, 3,
    Healthy, Healthy, IF_Kick | IF_RC,
  },
  /* BMBombData */
  {
    bomb_click_none, bomb_click_none, bomb_click_none,
    GoStop, FUSEnormal,
    BMTnormal, BMTnormal, BMTnormal,
  },
  /* BMGraphicsData */
  {
    {
      { "hole_floor", "Black", "BlueViolet", "Gold" },
      { "hole_floor", "Black", "BlueViolet", "Gold" },
      { "jizz",       "Black", "BlueViolet", "Gold" },
      { "hole_floor", "Black", "BlueViolet", "Gold" },
      { "extra",      "Black", "Yellow",     "White" },
      { "extra_O",    "Black", "Yellow",     "White" },
      EXTRA_BOMB,
      EXTRA_RANGE,
      EXTRA_TRAP,
      EXTRA_KICK,
      { "score_floor", "Black", "Gray50", "White" },
    },
  },
  /* BMMapData */
  {
    ShadowFull, DEall,
    { 0, 0, 0, 0, 0 },
    {
      { B,B,B,B,B,B,B,B,B,B,B,B,B },
      { B,_,_,_,_,_,_,_,_,_,_,_,B },
      { B,_,_,_,B,_,B,_,B,_,_,_,B },
      { B,_,_,_,_,_,_,_,_,_,_,_,B },
      { B,_,B,_,B,_,_,_,B,_,B,_,B },
      { B,_,_,_,_,_,_,_,_,_,_,_,B },
      { B,_,B,_,B,_,B,_,B,_,B,_,B },
      { B,_,_,_,_,_,_,_,_,_,_,_,B },
      { B,_,B,_,B,_,B,_,B,_,B,_,B },
      { B,_,_,_,_,_,_,_,_,_,_,_,B },
      { B,_,B,_,B,_,_,_,B,_,B,_,B },
      { B,_,_,_,_,_,_,_,_,_,_,_,B },
      { B,_,_,_,B,_,B,_,B,_,_,_,B },
      { B,_,_,_,_,_,_,_,_,_,_,_,B },
      { B,B,B,B,B,B,B,B,B,B,B,B,B }
    },
  },
};
