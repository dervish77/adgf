/*
 * Programm XBLAST V2.5.6 or higher
 * (C) by Oliver Vogel (e-mail: vogel@ikp.uni-koeln.de)
 * April 13th, 1997
 * started August 1993
 *
 * File: mystring.h
 * header for mystring.c
 *
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public Licences as published
 * by the Free Software Foundation; either version 2; or (at your option)
 * any later version
 *
 * This program is distributed in the hope that it will entertaining,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of 
 * MERCHANTABILTY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Publis License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.
 * 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 * $Id: mystring.h,v 1.1 1998/01/03 14:09:09 xblast Exp $
 * $Log: mystring.h,v $
 * Revision 1.1  1998/01/03 14:09:09  xblast
 * Initial revision
 *
 */

#ifndef _MYSTRING_C
#define  _MYSTRING_C

#ifdef _MYSTRING_C
#define _EXTERN 
#else
#define _EXTERN extern
#endif

#ifdef __STDC__
_EXTERN char *dup_string (char* ptr, int length);
_EXTERN char *sep_string (char *string, int sep);
_EXTERN int equal_string (char *s1, char *s2);
_EXTERN int string_to_interval (char *string, int *left, int *right);
_EXTERN int numeric_string (char *ptr);
_EXTERN char **split_string (char *string, int *largc);
#else
_EXTERN char *dup_string ();
_EXTERN char *sep_string ();
_EXTERN int equal_string ();
_EXTERN int string_to_interval ();
_EXTERN int numeric_string ();
_EXTERN char **split_string ();
#endif

#undef _EXTERN 

#endif
/*
 * end of file mystring.h
 */

