/*

The following piece of code was copied directly from http://devworld.apple.com/dev/qa/ops/ops15.html
According to Apple you must include it whenever you call control strip routines in a PPC project since
they forgot to put control strip support into their PPC libraries. Indeed, without this stuff you get a 
link error whenever you try to use ControlStrip.h. 

*/

/* This stuff now suddenly causes an illegal name overloading error in
   CW3P. Doesn't seem to be needed, so I therefore commented it out. */

/* Defined in current Universal Header */

#if 0 /* ndef _ControlStripDispatch */
enum {
    _ControlStripDispatch = 0xAAF2
};
#endif

#if GENERATINGCFM

/* If we're not generating CFM, then assume the
   68K inlines in the headers apply instead. */

#include <MixedMode.h>
#include <OSUtils.h>
pascal Boolean SBIsControlStripVisible ( void );
pascal void SBShowHideControlStrip(Boolean showIt);

/*  SBIsControlStripVisible is a Pascal routine, */
/*  dispatched from the selector in D0, returning */
/*  a Boolean result */
pascal Boolean SBIsControlStripVisible ( void )
{
    enum
        {
        uppSBIsControlStripVisibleInfo = kD0DispatchedPascalStackBased
            | RESULT_SIZE (SIZE_CODE (sizeof(Boolean)))
            | DISPATCHED_STACK_ROUTINE_SELECTOR_SIZE (kFourByteCode)
            };

            return CallUniversalProc (
            GetToolTrapAddress (_ControlStripDispatch),
            uppSBIsControlStripVisibleInfo, 0x00);
}

pascal void SBShowHideControlStrip(Boolean showIt)
{
    enum
        {
        uppSBShowHideControlStripInfo =
            kD0DispatchedPascalStackBased
            | DISPATCHED_STACK_ROUTINE_SELECTOR_SIZE (kFourByteCode)
            | DISPATCHED_STACK_ROUTINE_PARAMETER
                (1, SIZE_CODE (sizeof (showIt)))
            };

            CallUniversalProc (
            GetToolTrapAddress (_ControlStripDispatch),
            uppSBShowHideControlStripInfo, 0x01, showIt);
}

#else   /*  not GENERATINGCFM */
#include <ControlStrip.h>
#endif /*  GENERATINGCFM */

