#define VERSION "7.2.2 (June 1998)"

#define COPYRIGHT "Copyright 1986-1998 Stanley T. Shebs"
