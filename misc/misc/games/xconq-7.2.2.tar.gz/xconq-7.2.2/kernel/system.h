/* Definitions of system-specific things for Xconq.
   Copyright (C) 1995, 1996, 1997 Stanley T. Shebs.

Xconq is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.  See the file COPYING.  */

/* Note that this assumes module.h is already included. */

extern FILE *open_module_library_file PARAMS ((Module *module));
extern FILE *open_module_explicit_file PARAMS ((Module *module));
extern FILE *open_library_file PARAMS ((char *filename));
extern char *default_library_filename PARAMS ((void));
extern char *news_filename PARAMS ((void));
extern char *saved_game_filename PARAMS ((void));
extern char *checkpoint_filename PARAMS ((void));
extern char *error_save_filename PARAMS ((void));
extern char *statistics_filename PARAMS ((void));
extern FILE *open_scorefile_for_reading PARAMS ((char *name));
extern FILE *open_scorefile_for_writing PARAMS ((char *name));
extern void close_scorefile_for_writing PARAMS ((FILE *fp));
extern void make_pathname PARAMS ((char *path, char *name, char *extn,
				  char *pathbuf));
extern void remove_saved_game PARAMS ((void));
extern void init_signal_handlers PARAMS ((void));
extern int n_seconds_elapsed PARAMS ((int n));
extern int n_ms_elapsed PARAMS ((int n));
extern void record_ms PARAMS ((void));

extern void open_remote_connection PARAMS ((char *methodname));
extern void close_remote_connection PARAMS ((void));
extern void low_send PARAMS ((int id, char *buf));
extern int low_receive PARAMS ((int *id, char *buf, int maxchars,
				int timeout));

/* defined in init.c but referenced in mac.c ... */
extern void add_library_path PARAMS ((char *path));

extern int serial_port_dialog PARAMS ((void));

