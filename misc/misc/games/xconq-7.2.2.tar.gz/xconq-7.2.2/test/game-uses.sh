#! /bin/bash

cd $1/../lib

grep '^"' game.dir | sed -e 's/^"\([^"]*\)"$/game dir \1.g/' > db

grep '(base-module ' *.g | sed -e 's/^\([^:]*\):[^"]*"\([^"]*\)".*$/base \1 \2.g/' >> db

grep '(default-base-module ' *.g | sed -e 's/^\([^:]*\):[^"]*"\([^"]*\)".*$/dflt \1 \2.g/' >> db

grep '(include ' *.g | sed -e 's/^\([^:]*\):[^"]*"\([^"]*\)".*$/incl \1 \2.g/' >> db

for libfile in *.g ; do
	rslt=`grep "^[^ ]* [^ ]* ${libfile}" db | sed -e 's/^\([^ ]* [^ ]*\) .*$/(\1)/' | tr '\012' ' '`
	echo ${libfile} '	' ${rslt}
done

