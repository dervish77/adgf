#! /bin/bash

cd $1/../lib

for sym in `grep -h '^(imf ' *.imf | sed -e 's/^(imf "\([^"]*\)".*$/\1/' | sort |uniq` ; do
	grep -c "image-name \"${sym}\"" *.g | grep -v ':0$' >rslt1
	grep -c "emblem-name \"${sym}\"" *.g | grep -v ':0$' >rslt2
	grep -c "unit-type ${sym}[^A-Za-z-]" *.g | grep -v ':0$' >rslt3
	grep -c "unit-type ${sym}$" *.g | grep -v ':0$' >rslt4
	grep -c "terrain-type ${sym}[^A-Za-z-]" *.g | grep -v ':0$' >rslt5
	grep -c "terrain-type ${sym}$" *.g | grep -v ':0$' >rslt6
	rslt=`cat rslt[1-6] | sed -e 's/:1$//' | sort | uniq | tr '\012' ' '`
	echo ${sym} '	' ${rslt}
done

