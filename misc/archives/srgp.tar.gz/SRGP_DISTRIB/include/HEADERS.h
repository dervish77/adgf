
#ifdef THINK_C
#  include <MacHeaders>
/* #include <ColorToolbox.h> */
#  include <stdlib.h>
#  include <string.h>
#  include <assert.h>
#  include <unix.h>
#endif

/* THIS FILE IS TO BE PRECOMPILED TO FORM A FAST-LOADING "HEADERS.h" FILE.
   See page 117 of THINK C User's Manual
   (Note - Mar 1993 - precompiling is no longer recommended)
 */
