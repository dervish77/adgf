#! /bin/sh
#
# combine split source and data files into their original
#
cat advdat.xaa advdat.xab advdat.xac > ADVDAT
rm advdat.xaa advdat.xab advdat.xac
cat aamain.f.xaa aamain.f.xab > aamain.f
rm aamain.f.xaa aamain.f.xab
cat asubs.f.xaa asubs.f.xab > asubs.f
rm asubs.f.xaa asubs.f.xab
