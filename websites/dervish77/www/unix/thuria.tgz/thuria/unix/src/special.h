/*****************************************************************************
 *
 *	Special effect ID's for Dungeons of Thuria.
 *
 *	File:	special.h
 *
 *	Author: Brian Lingard
 *
 *	Date:	12/04/96
 *
 *	Revs:
 *	  0.0 	12/04/96  originated
 *
 *****************************************************************************/


#ifndef SPECIAL_H
#define SPECIAL_H



#define SE_NULL		-1

#define SE_CHEST_EMPTY	0
#define SE_CHEST_FULL	1
#define SE_ODOOR_LOCKED	2
#define SE_ODOOR_CLOSED	3
#define SE_ODOOR_OPEN	4
#define SE_SKEL_SITS	5
#define SE_SKEL_ATTACK	6
#define SE_SKEL_DEAD	7
#define SE_BEAV_HUNGRY	8
#define SE_BEAV_BITES	9
#define SE_BEAV_DEAD	10
#define SE_IDOOR_CLOSED	11
#define SE_IDOOR_OPEN	12
#define SE_SWIFT_WARN1	13
#define SE_SWIFT_WARN2	14
#define SE_STATUE_NORTH	15
#define SE_STATUE_SOUTH	16
#define SE_ROPE_COILED	17
#define SE_ROPE_RISEN	18
#define SE_GRATE_LOCKED	19
#define SE_GRATE_CLOSED	20
#define SE_GRATE_OPEN	21
#define SE_BEAR_HUNGRY	22
#define SE_BEAR_GONE	23
#define SE_BEAR_DEAD	24
#define SE_SLAB_CLOSED	25
#define SE_SLAB_OPEN	26
#define SE_BRIDGE_NO	27
#define SE_BRIDGE_NO2	28
#define SE_BRIDGE_YES	29
#define SE_BRIDGE_BRK	30
#define SE_BOOTS_OFF	31
#define SE_BOOTS_ON	32
#define SE_ANSWER_0	33
#define SE_ANSWER_1	34
#define SE_ANSWER_2	35
#define SE_ANSWER_3	36



#define MG_NULL		-1

#define MG_XYZZY	0
#define MG_PLUGH	1
#define MG_PLOVER	2
#define MG_PILLOW	3
#define MG_MARCUS	4
#define MG_NEEP		5


#define RK_NULL		-1

#define RK_RANK0	0
#define RK_RANK1	1
#define RK_RANK2	2
#define RK_RANK3	3
#define RK_RANK4	4
#define RK_RANK5	5


#endif /* SPECIAL_H */

/* end of special.h */
