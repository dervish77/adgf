/*****************************************************************************
 *
 *	Soruce code for S-records conversion utility.
 *
 *	File:	srec85.c
 *
 *	Author: Brian Lingard
 *
 *	Date:	12/04/96
 *
 *	Revs:
 *	  0.0 	12/04/96  originated
 *
 *****************************************************************************/


#include <stdio.h>

#ifndef DEV8085_H
#include "dev8085.h"
#endif



  
/*  main	- main program
 *
 *  Parameters:
 *	argc	- number of command line arguments
 *	argv	- pointer to command line argument array
 *
 *  Returns:
 *	none
 */
void 
main(int argc, char **argv)
{




   exit(0);
}


/* end of srec85.c */
